"""Central LLM wrapper. Model: Llama 3.3-70B-Instruct, provider-configurable.

  LLM_PROVIDER=groq     -> llama-3.3-70b-versatile (Groq API)
  LLM_PROVIDER=together -> meta-llama/Llama-3.3-70B-Instruct-Turbo
  LLM_PROVIDER=ollama   -> local llama3.3:70b (http://localhost:11434)
  LLM_PROVIDER=none     -> deterministic rule-based fallback (default, zero setup)

Deterministic math (risk score, allocation, benchmarking, SIP) is always
computed in core/*.py, never delegated to the LLM. The LLM is used only for:
intent classification assistance, FinAdvisor conversational replies, and RAG
answer composition -- and every call degrades gracefully on any error.
"""
from __future__ import annotations

import os
import json

from dotenv import load_dotenv

load_dotenv()

PROVIDER = os.getenv("LLM_PROVIDER", "none").strip().lower()
API_KEY = os.getenv("LLM_API_KEY", "").strip()
MODEL_OVERRIDE = os.getenv("LLM_MODEL", "").strip()
BASE_URL_OVERRIDE = os.getenv("LLM_BASE_URL", "").strip()

DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "together": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    "ollama": "llama3.3:70b",
}
DEFAULT_BASE_URLS = {
    "groq": "https://api.groq.com/openai/v1/chat/completions",
    "together": "https://api.together.xyz/v1/chat/completions",
    "ollama": "http://localhost:11434/api/chat",
}

TIMEOUT_SECONDS = 20


def is_live() -> bool:
    """Whether a real LLM backend is configured and usable."""
    if PROVIDER == "none":
        return False
    if PROVIDER in ("groq", "together") and not API_KEY:
        return False
    return True


def _model_name() -> str:
    return MODEL_OVERRIDE or DEFAULT_MODELS.get(PROVIDER, "")


def _base_url() -> str:
    return BASE_URL_OVERRIDE or DEFAULT_BASE_URLS.get(PROVIDER, "")


def chat(messages: list[dict], system: str = "", temperature: float = 0.4,
         max_tokens: int = 600) -> str | None:
    """Send a chat completion request. Returns None on any failure so callers
    can fall back to rule-based logic -- never raises."""
    if not is_live():
        return None

    full_messages = []
    if system:
        full_messages.append({"role": "system", "content": system})
    full_messages.extend(messages)

    try:
        import requests
        if PROVIDER in ("groq", "together"):
            resp = requests.post(
                _base_url(),
                headers={
                    "Authorization": f"Bearer {API_KEY}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": _model_name(),
                    "messages": full_messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
                timeout=TIMEOUT_SECONDS,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()

        elif PROVIDER == "ollama":
            resp = requests.post(
                _base_url(),
                json={
                    "model": _model_name(),
                    "messages": full_messages,
                    "stream": False,
                    "options": {"temperature": temperature},
                },
                timeout=TIMEOUT_SECONDS,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["message"]["content"].strip()

    except Exception:
        return None

    return None


def provider_label() -> str:
    if not is_live():
        return "Rule-based fallback (no LLM configured)"
    return f"Llama 3.3-70B-Instruct via {PROVIDER}"

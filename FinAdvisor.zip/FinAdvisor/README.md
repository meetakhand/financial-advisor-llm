# NexWealth AI — "FinAdvisor"

A locally hosted Streamlit app implementing an **AI-native wealth management
experience**: a multi-agent, retrieval-augmented financial-advisory workflow
where planning, review, and human-in-the-loop approval all happen inside a
single chat panel. An **Agent Orchestrator** routes user requests to
specialized agents (Goal Planning, Risk Profiling, Portfolio Analysis,
Benchmarking, Recommendation, Report/Output), powered by **Llama
3.3-70B-Instruct** (provider-configurable), with a deterministic rule-based
fallback so the app always runs offline with zero setup.

Serves **US customers** (currency: USD). Four user journeys: **Retirement
Planning**, **Child Education**, **Buy Home**, and **Financial Q&A**
(RAG-grounded, with citations).

> Educational demo. Nothing in this app is financial advice.

## Run locally

```bash
git clone <repo> && cd nexwealth-ai
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env         # optional: add LLM_PROVIDER + LLM_API_KEY for real Llama 3.3-70B
python -m rag.ingest         # one-time: build the local knowledge base (ChromaDB)
streamlit run app.py         # opens http://localhost:8501
```

The app works with **zero configuration** — `.env` is optional. With
`LLM_PROVIDER=none` (the default), FinAdvisor's conversational replies and
RAG answers use a deterministic rule-based / keyword-retrieval fallback. All
domain math (risk scoring, model allocations, SIP/future-value, drift,
benchmarking) is always computed in code, never delegated to the LLM.

### Using real Llama 3.3-70B-Instruct

Set in `.env`:

- **Groq** — `LLM_PROVIDER=groq`, `LLM_API_KEY=<your groq key>` (model:
  `llama-3.3-70b-versatile`)
- **Together AI** — `LLM_PROVIDER=together`, `LLM_API_KEY=<your together key>`
  (model: `meta-llama/Llama-3.3-70B-Instruct-Turbo`)
- **Ollama (fully local, no key)** — run `ollama pull llama3.3:70b`, then set
  `LLM_PROVIDER=ollama`

## What's inside

- **100 seeded, deterministic US customers** with holdings (incl. purchase
  **start date**), goals, income, and a risk profile — stored in
  `core/data.py` and a SQLite `user_memory.db` for conversation history and
  human-in-the-loop decisions.
- **FinAdvisor chat panel** (`agents/advisor.py` + `ui/page_advisor.py`) —
  the primary, AI-native surface for the whole experience:
  - Introduces itself, offers the four journeys as clickable cards.
  - Guided goal setting, followed by a **current portfolio** step (Equity /
    Debt / Mutual Fund / Pension balances with start dates).
  - An intuitive risk-profiling questionnaire with a plain-language result
    (gauge + band description) shown right in the chat.
  - An **embedded live dashboard** (allocation, goal progress, current vs.
    target) rendered inline after the plan is generated.
  - **Three AI-generated investment options** with Approve / Reject /
    Override human-in-the-loop review — every decision requires a typed
    response, which is logged and surfaces in the Report.
  - Free-text Financial Q&A via RAG (ChromaDB + `all-MiniLM-L6-v2`
    embeddings, top-k=4, with citations and a follow-up question) available
    at any point.
- **Agent Orchestrator** (`agents/orchestrator.py`) — routes: Goal Planning →
  Risk Profiling → Portfolio Analysis → Benchmarking → Recommendation →
  Report, exactly per the documented business flow.
- **Guardrails** (`guardrails.py`) — input screening (blocks prompt
  injection / out-of-scope / unsafe requests) and output screening
  (not SEC-registered advice disclaimer) wrap every advisor/agent turn.
- **Knowledge base** (`knowledge/*.md`) — original educational summaries
  covering asset allocation, mutual funds/ETFs, systematic investing,
  emergency funds, retirement accounts (401(k)/IRA), tax basics,
  diversification, bonds, and inflation.

## Project structure

```
app.py                     Streamlit entry point & navigation
llm.py                     Llama 3.3-70B-Instruct wrapper (provider-config)
guardrails.py              Input/output safety
core/
  data.py                  100 US customers, SQLite user memory
  calculators.py           FV, SIP, success probability
  risk.py                  Risk questionnaire + scoring
  models.py                Four model portfolios
  benchmark.py             Benchmark blends & tracking
  recommend.py             Drift, turnover, fit score, rebalancing actions
  market.py                Bundled sample market data (swap-in points noted)
agents/
  orchestrator.py, intent.py, goal_agent.py, risk_agent.py,
  portfolio_agent.py, benchmark_agent.py, recommend_agent.py,
  report_agent.py, advisor.py
rag/
  ingest.py                Build the ChromaDB collection
  retriever.py              Top-k retrieval + citations (+ keyword fallback)
knowledge/                 Curated educational docs (US)
ui/
  page_*.py                Page renderers
  dashboard_components.py  Shared embeddable dashboard (chat panel, Dashboard, Report)
  charts.py, formatting.py, session.py
```

## Swap-in points for production data

- `core/market.py` — replace bundled sample prices/returns with Alpha
  Vantage/IEX/Polygon and FRED; replace the illustrative benchmark returns
  with a live index feed.
- `llm.py` — point `LLM_BASE_URL`/`LLM_API_KEY` at your production Llama
  3.3-70B-Instruct deployment.
- `core/data.py` — swap the deterministic generator for a real customer
  database; the SQLite `user_memory.db` conversation log can be replaced
  with any persistent store.

## Acceptance checklist

- [x] Runs with `streamlit run app.py` and no API key (rule-based fallback)
- [x] Uses Llama 3.3-70B-Instruct when `LLM_PROVIDER` + key (or Ollama) is set
- [x] 100 seeded US customers, currency-correct throughout
- [x] FinAdvisor introduces itself and offers the four journeys as cards
- [x] Goal setting is followed by a current-portfolio step and an intuitive
      risk assessment, all inside the chat panel
- [x] Each planning journey returns 3 investment options with model
      portfolio + target allocation + benchmark + drift + rebalancing, each
      reviewable via Approve / Reject / Override (response required)
- [x] Financial Q&A returns RAG-grounded answers with citations + follow-up
- [x] Orchestrator routes correctly; guardrails run every turn; disclaimers
      appended
- [x] Risk scoring / allocations / benchmarking / SIP math match the exact
      documented formulas
- [x] Dashboard and Report show current vs. target allocation and embed the
      live dashboard + human-in-the-loop decision log
- [x] Clean Plotly dashboards; USD-formatted throughout

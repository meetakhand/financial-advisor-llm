# Inflation and Why It Matters for Goal Planning

Source: RBI, Federal Reserve (FRED) educational materials, Investopedia — summarized.

Inflation is the rate at which prices rise over time, eroding the purchasing
power of money. A goal that costs a fixed amount today will typically cost
more by the time you need the funds — this is especially significant for
long-horizon goals like retirement (decades away) or child education
(years away, and education costs have historically risen faster than
general inflation in many markets).

**Why this matters for planning:**
- A retirement corpus or education fund target should generally be set in
  *future*, inflation-adjusted terms, not today's prices — otherwise the
  goal will fall short of actual purchasing power needed.
- Keeping too much of a long-horizon goal in cash or low-yielding
  instruments risks losing real value to inflation over time, even though
  the nominal balance never goes down.
- Growth-oriented assets (equities) have historically outpaced inflation
  over long periods better than cash or short-term fixed income, which is
  one reason longer time horizons can support a higher equity allocation.

NexWealth AI's Child Education and Retirement journeys apply an
inflation-adjustment factor when projecting target costs, and every SIP
calculation projects growth against that inflated target so the plan
reflects real, not just nominal, purchasing power.

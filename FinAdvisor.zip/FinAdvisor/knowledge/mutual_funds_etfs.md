# Mutual Funds vs ETFs

Source: FINRA, Investor.gov, Investopedia — summarized.

Both mutual funds and ETFs (exchange-traded funds) pool money from many
investors to buy a diversified basket of securities, managed according to a
stated strategy or index.

**Mutual funds**
- Priced once a day after market close (net asset value, NAV).
- Bought/sold directly through the fund company or a broker/platform, often
  via automatic monthly contributions (a SIP / dollar-cost-averaging plan).
- Can be actively managed (manager picks holdings) or passively managed
  (tracks an index).
- May carry sales loads and typically have higher expense ratios if actively
  managed.

**ETFs**
- Trade on an exchange throughout the day like a stock, so prices move
  intraday.
- Usually passively track an index (e.g., VOO tracks the S&P 500), though
  actively managed ETFs exist.
- Generally lower expense ratios than actively managed mutual funds.
- Require a brokerage account to trade.

**Choosing between them:** if you want automatic, disciplined monthly
investing without needing a trading account open during market hours, a
mutual fund with automatic contributions is often simpler. If you want
intraday flexibility and the lowest-cost index exposure, an ETF may fit
better. Expense ratio, tracking error, and liquidity are the key factors to
compare.

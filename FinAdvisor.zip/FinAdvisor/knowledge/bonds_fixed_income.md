# Bonds and Fixed Income

Source: FINRA, Investor.gov, Investopedia — summarized.

A bond is essentially a loan you make to a government or company, which
pays you periodic interest (the "coupon") and returns your principal at
maturity. Fixed income generally carries lower expected returns than
equities but also lower volatility, and it plays a stabilizing role in a
diversified portfolio.

**Key concepts:**
- **Interest rate risk** — bond prices move inversely to interest rates;
  longer-maturity bonds are more sensitive to rate changes than short-term
  bonds.
- **Credit risk** — the risk that the issuer fails to pay interest or
  principal; US Treasuries are generally considered the lowest credit risk,
  with investment-grade and high-yield corporate bonds carrying more.
- **Yield** — the return you earn accounting for price and coupon; not the
  same as the coupon rate alone.

**Examples:** Treasury bonds/notes/bills, investment-grade corporate bonds,
and aggregate bond index funds (e.g., tracking the Bloomberg US Aggregate
Bond Index) that anchor the "risk free" rate used across the market.

Fixed income allocation typically increases as an investor's time horizon
shortens or risk tolerance decreases — hence the higher fixed-income
weighting in the Conservative model portfolio versus the Aggressive one.

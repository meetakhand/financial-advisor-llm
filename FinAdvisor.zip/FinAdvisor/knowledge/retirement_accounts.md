# Retirement Accounts: 401(k) and IRA

Source: IRS.gov, Investor.gov — summarized.

- **401(k)** — employer-sponsored retirement plan; contributions are often
  pre-tax (traditional) or after-tax (Roth), and many employers match a
  portion of contributions — generally worth capturing in full since it is
  effectively free money.
- **IRA (Individual Retirement Account)** — opened independently of an
  employer. Traditional IRAs offer tax-deferred growth; Roth IRAs offer
  tax-free qualified withdrawals in retirement. Annual contribution limits
  apply and are set by the IRS.
- **Pension plans** — some employers still offer defined-benefit pensions,
  which pay a guaranteed income in retirement based on salary and years of
  service, distinct from defined-contribution accounts like a 401(k).
- Early withdrawals before age 59½ generally trigger taxes and a 10% penalty,
  with some exceptions.

Tax-advantaged retirement accounts are generally a priority destination for
long-term retirement savings before using fully taxable investment accounts,
because the tax treatment materially improves long-run compounding.

# Asset Allocation Basics

Source: Investor.gov (SEC Office of Investor Education), Investopedia — summarized.

Asset allocation is how you split your investments across broad categories such
as equities (stocks), fixed income (bonds), cash, and alternatives like gold.
The mix matters more than picking individual securities for most long-term
outcomes, because different asset classes respond differently to the same
economic conditions — this is the basis of diversification.

A common framework:
- **Equity** — highest long-run growth potential, highest short-term volatility.
- **International equity** — diversifies away from single-country risk.
- **Fixed income** — dampens volatility, provides income, generally lower
  long-run returns than equity.
- **Gold / alternatives** — can act as a hedge during inflation or equity
  drawdowns.
- **Cash** — safety and liquidity for near-term needs, lowest long-run return.

Your ideal mix depends on your time horizon, risk tolerance (how you feel
about volatility) and risk capacity (how much volatility you can financially
afford), and the specific goal the money is earmarked for. A 25-year-old
saving for retirement 35 years away can typically afford more equity than
someone saving for a home down payment in 2 years.

Rebalancing — periodically buying/selling to bring your portfolio back to its
target mix — helps manage risk as markets move your allocation away from plan.

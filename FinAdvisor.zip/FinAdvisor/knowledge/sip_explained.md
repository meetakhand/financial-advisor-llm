# Systematic Investing & Dollar-Cost Averaging (SIP)

Source: FINRA, Investor.gov investor education — summarized.

A SIP (systematic investment plan) is a fixed amount invested automatically
at regular intervals (usually monthly) into a mutual fund or ETF, rather
than investing a lump sum at once. In the US this is commonly called
"dollar-cost averaging," typically set up via automatic brokerage or 401(k)
payroll transfers.

**Why it works:**
- **Discipline** — automation removes the temptation to time the market or
  skip contributions.
- **Dollar-cost averaging** — you buy more shares when prices are low and
  fewer when prices are high, which smooths out your average purchase cost
  over time versus a single lump-sum bet.
- **Compounding** — starting early and staying consistent lets returns
  compound on both your contributions and prior gains.

**How the required monthly amount is calculated:** given a target amount, a
time horizon, and an assumed rate of return, the required monthly
contribution ("required SIP") is solved from the future-value-of-annuity
formula: FV = P(1+r)^n + C[((1+r)^n − 1)/r], where P is your current
savings, C is the monthly contribution, r is the monthly rate, and n is the
number of months. NexWealth AI computes this directly for every goal.

A SIP is not a guarantee of positive returns — the underlying fund can still
lose value — but historically, disciplined long-horizon systematic investing
in diversified equity funds has smoothed volatility better than one-time
lump-sum investing for most retail investors.

# Diversification

Source: Investor.gov, SEBI investor education — summarized.

Diversification means spreading investments across assets that don't all
move in the same direction at the same time, so that a decline in one
holding is cushioned by stability or gains elsewhere. It is one of the few
tools in investing that can reduce risk without necessarily reducing
expected long-run return.

**Dimensions of diversification:**
- **Across asset classes** — equity, fixed income, gold, cash each behave
  differently across economic cycles.
- **Across geographies** — domestic-only portfolios carry concentrated
  single-country risk; adding international exposure spreads that risk.
- **Across sectors** — being overweight a single sector (e.g., only
  technology stocks) increases exposure to sector-specific shocks.
- **Across individual securities** — holding a handful of individual stocks
  is riskier than holding a broad index fund of hundreds of companies.

Diversification does not eliminate risk entirely (it cannot protect against
a broad market-wide downturn) and it does not guarantee a profit, but it is
a foundational risk-management principle behind the model portfolios used
in this app.

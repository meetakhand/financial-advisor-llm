# Emergency Fund Basics

Source: Investor.gov, FINRA financial literacy materials — summarized.

An emergency fund is cash (or near-cash, like a liquid/money-market fund)
set aside to cover unexpected expenses — job loss, medical bills, urgent
home or car repairs — without having to sell long-term investments at a bad
time or take on high-interest debt.

**How much is enough?** A common guideline is 3–6 months of essential
living expenses. Consider the higher end of that range (or more) if:
- Your income is variable or you're self-employed/business owner.
- You are the sole earner for your household.
- You have significant dependents.
- Your industry is cyclical or you anticipate a job change.

**Where to keep it:** liquidity and capital safety matter more than returns
here. Suitable options include a high-yield savings account or a
money-market fund — not equities, which can drop sharply exactly when you
need the cash most.

**Sequencing:** most financial educators suggest building at least a partial
emergency fund (e.g., 1 month of expenses) before aggressively investing
toward other goals, then continuing to build it in parallel with long-term
investing.

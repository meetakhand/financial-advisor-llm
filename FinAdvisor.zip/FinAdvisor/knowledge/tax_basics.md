# Tax-Saving Basics (United States)

Source: IRS.gov, Investor.gov — summarized.

- Contributions to a traditional 401(k)/IRA reduce taxable income today;
  Roth accounts are funded with after-tax money but grow and withdraw
  tax-free (if qualified).
- Long-term capital gains (assets held over 1 year) are taxed at lower rates
  than short-term gains or ordinary income.
- Tax-loss harvesting — selling a losing position to offset realized gains
  elsewhere — is a legal, commonly used year-end strategy.
- Health Savings Accounts (HSAs), if eligible, offer triple tax advantages:
  pre-tax contributions, tax-free growth, and tax-free withdrawals for
  qualified medical expenses.
- 529 education savings plans grow tax-free and allow tax-free withdrawals
  for qualified education expenses; many states also offer a state tax
  deduction for contributions.

Tax rules change frequently and vary by individual circumstances — this is a
simplified educational summary, not tax advice. Consult a qualified tax
professional (CPA) for your specific situation.

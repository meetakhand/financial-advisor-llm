"""The four model portfolios and their target allocations (build spec section 6)."""
from __future__ import annotations

from dataclasses import dataclass, field

ASSET_CLASSES = ["Equity", "International", "Fixed Income", "Gold", "Cash"]


@dataclass
class ModelPortfolio:
    name: str
    allocation: dict  # asset class -> target %
    expected_return: float  # annualized, decimal
    est_volatility: float  # annualized, decimal


MODEL_PORTFOLIOS: dict[str, ModelPortfolio] = {
    "Conservative": ModelPortfolio(
        name="Conservative",
        allocation={"Equity": 14, "International": 6, "Fixed Income": 55, "Gold": 10, "Cash": 15},
        expected_return=0.06, est_volatility=0.05,
    ),
    "Moderate": ModelPortfolio(
        name="Moderate",
        allocation={"Equity": 32, "International": 13, "Fixed Income": 35, "Gold": 10, "Cash": 10},
        expected_return=0.08, est_volatility=0.08,
    ),
    "Growth": ModelPortfolio(
        name="Growth",
        allocation={"Equity": 46, "International": 19, "Fixed Income": 20, "Gold": 8, "Cash": 7},
        expected_return=0.10, est_volatility=0.12,
    ),
    "Aggressive": ModelPortfolio(
        name="Aggressive",
        allocation={"Equity": 57, "International": 25, "Fixed Income": 8, "Gold": 6, "Cash": 4},
        expected_return=0.115, est_volatility=0.16,
    ),
}

BAND_TO_MODEL = {
    "Conservative": "Conservative",
    "Moderate": "Moderate",
    "Growth": "Growth",
    "Aggressive": "Aggressive",
}


def model_for_band(risk_band: str) -> ModelPortfolio:
    return MODEL_PORTFOLIOS[BAND_TO_MODEL.get(risk_band, "Moderate")]

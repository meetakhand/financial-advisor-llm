"""Recommendation Engine: drift, turnover, fit score, prioritized rebalancing
actions (build spec section 6).

  drift = current - target per asset class
  turnover = sum(|drift|) / 2
  fit score = 100 - turnover * 1.6
  |drift| >= 5% triggers a rebalancing action, prioritized High/Medium/Low
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.models import ASSET_CLASSES, ModelPortfolio

DRIFT_THRESHOLD = 5.0


@dataclass
class RebalanceAction:
    asset_class: str
    direction: str   # "Reduce" or "Increase"
    magnitude: float  # percentage points
    priority: str     # High / Medium / Low


@dataclass
class RecommendationResult:
    target_allocation: dict
    current_allocation: dict
    drift: dict
    turnover: float
    fit_score: float
    actions: list
    needs_rebalancing: bool


def compute_drift(current_allocation: dict, target_allocation: dict) -> dict:
    drift = {}
    for ac in ASSET_CLASSES:
        cur = current_allocation.get(ac, 0.0)
        tgt = target_allocation.get(ac, 0.0)
        drift[ac] = round(cur - tgt, 1)
    return drift


def compute_turnover(drift: dict) -> float:
    return sum(abs(v) for v in drift.values()) / 2.0


def compute_fit_score(turnover: float) -> float:
    return max(0.0, round(100 - turnover * 1.6, 1))


def priority_for_magnitude(magnitude: float) -> str:
    if magnitude >= 12:
        return "High"
    if magnitude >= 5:
        return "Medium"
    return "Low"


def build_actions(drift: dict) -> list[RebalanceAction]:
    actions = []
    for ac, d in drift.items():
        if abs(d) >= DRIFT_THRESHOLD:
            direction = "Reduce" if d > 0 else "Increase"
            actions.append(RebalanceAction(
                asset_class=ac,
                direction=direction,
                magnitude=abs(d),
                priority=priority_for_magnitude(abs(d)),
            ))
    actions.sort(key=lambda a: -a.magnitude)
    return actions


def generate_recommendation(current_allocation: dict, model: ModelPortfolio) -> RecommendationResult:
    target = model.allocation
    drift = compute_drift(current_allocation, target)
    turnover = compute_turnover(drift)
    fit = compute_fit_score(turnover)
    actions = build_actions(drift)
    return RecommendationResult(
        target_allocation=target,
        current_allocation=current_allocation,
        drift=drift,
        turnover=round(turnover, 1),
        fit_score=fit,
        actions=actions,
        needs_rebalancing=len(actions) > 0,
    )


def prioritized_text_recommendations(rec: RecommendationResult, model_name: str) -> list[str]:
    lines = []
    if not rec.needs_rebalancing:
        lines.append(f"Your portfolio is well aligned with the {model_name} model — no rebalancing needed right now.")
        return lines
    for a in rec.actions:
        lines.append(f"[{a.priority}] {a.direction} {a.asset_class} by {a.magnitude:.1f} percentage points to realign with the {model_name} model.")
    return lines

"""Deterministic financial math: future value, required SIP, goal success probability.

All calculations use monthly compounding. These are always computed in code,
never delegated to the LLM (see build spec section 6/9).
"""
from __future__ import annotations

import math


def future_value(present_value: float, monthly_contribution: float,
                  annual_rate: float, years: float) -> float:
    """FV = P(1+r)^n + C[((1+r)^n - 1)/r], monthly compounding.

    annual_rate is a decimal (e.g. 0.08 for 8%). years may be fractional.
    """
    n = max(years, 0) * 12
    r = annual_rate / 12.0
    if n <= 0:
        return present_value
    if r == 0:
        return present_value + monthly_contribution * n
    growth = (1 + r) ** n
    fv = present_value * growth + monthly_contribution * ((growth - 1) / r)
    return fv


def required_sip(present_value: float, target_amount: float,
                  annual_rate: float, years: float) -> float:
    """Solve for the monthly contribution C such that FV(P, C, r, n) = target."""
    n = max(years, 0) * 12
    r = annual_rate / 12.0
    if n <= 0:
        return max(target_amount - present_value, 0.0)
    growth = (1 + r) ** n
    remaining = target_amount - present_value * growth
    if remaining <= 0:
        return 0.0
    if r == 0:
        return remaining / n
    c = remaining / ((growth - 1) / r)
    return max(c, 0.0)


def success_probability(projected_amount: float, target_amount: float) -> float:
    """Simple projected/target ratio, clamped to [0, 100] and capped with
    diminishing returns above 100% funded so the number stays interpretable."""
    if target_amount <= 0:
        return 100.0
    ratio = projected_amount / target_amount
    if ratio >= 1:
        # Comfortably funded: approach 99% asymptotically, never claim certainty.
        pct = 99.0 - 15.0 * math.exp(-(ratio - 1) * 3)
    else:
        pct = ratio * 92.0
    return round(clamp(pct, 1.0, 99.0), 1)


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def inflate(amount: float, annual_inflation: float, years: float) -> float:
    """Project a future cost given an annual inflation rate."""
    return amount * ((1 + annual_inflation) ** max(years, 0))


def years_between(current_year: int, target_year: int) -> float:
    return max(target_year - current_year, 0)

"""Bundled sample market data (illustrative, deterministic). US customers only.

Swap-in point for real data: Alpha Vantage / IEX / Polygon for prices, FRED
for rates & the bond index.

Everything here is static and clearly illustrative -- no live network calls.
"""
from __future__ import annotations

# ticker -> (name, sector, asset_class, current_price, twelve_month_return)
US_INSTRUMENTS = {
    "VOO":       ("Vanguard S&P 500 ETF", "Broad Market", "Equity", 512.30, 0.132),
    "VXUS":      ("Vanguard Total International Stock ETF", "International", "International", 62.10, 0.081),
    "MSFT":      ("Microsoft Corp", "Technology", "Equity", 445.20, 0.201),
    "AAPL":      ("Apple Inc", "Technology", "Equity", 227.80, 0.152),
    "AMZN":      ("Amazon.com Inc", "Consumer Discretionary", "Equity", 186.40, 0.244),
    "JNJ":       ("Johnson & Johnson", "Healthcare", "Equity", 154.60, 0.041),
    "JPM":       ("JPMorgan Chase & Co", "Financials", "Equity", 214.90, 0.276),
    "BND":       ("Vanguard Total Bond Market ETF", "Aggregate Bond", "Fixed Income", 72.40, 0.037),
    "TLT":       ("iShares 20+ Yr Treasury Bond ETF", "Long Treasury", "Fixed Income", 91.10, -0.021),
    "GLD":       ("SPDR Gold Shares", "Gold", "Gold", 238.70, 0.187),
    "CASH_USD":  ("Cash / Money Market", "Cash", "Cash", 1.00, 0.045),
}


def instrument_universe() -> dict:
    return US_INSTRUMENTS


def current_price(symbol: str) -> float:
    return US_INSTRUMENTS.get(symbol, (None, None, None, 1.0, None))[3]


def instrument_info(symbol: str):
    return US_INSTRUMENTS.get(symbol, (symbol, "Other", "Equity", 1.0, 0.0))


# Blended benchmark 12-month returns by model band (illustrative, build spec sec.6)
BENCHMARK_BLEND_RETURNS = {
    "Conservative": 0.057,
    "Moderate": 0.076,
    "Growth": 0.091,
    "Aggressive": 0.103,
}

# Broad market (S&P 500) 12-month return, for "vs market" comparison, illustrative
BROAD_MARKET_RETURN = 0.147

BENCHMARK_COMPONENTS = {
    "Equity": "S&P 500",
    "International": "MSCI ACWI ex-US",
    "Fixed Income": "US Aggregate Bond Index",
    "Gold": "Gold Spot (USD)",
    "Cash": "US T-Bill 3M",
}

"""Deterministic sample data: 100 US customers, holdings, goals, and a
SQLite-backed "user memory" store for conversation/session state.

Everything is generated from a fixed seed so runs are reproducible.
NexWealth AI serves US customers only (currency: USD).
"""
from __future__ import annotations

import os
import random
import sqlite3
from dataclasses import dataclass, field, asdict
from datetime import date

from core.market import US_INSTRUMENTS
from core.risk import compute_risk, QUESTIONNAIRE

SEED = 42
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "user_memory.db")

USA_FIRST_NAMES = ["James", "Michael", "Robert", "David", "William", "Emma", "Olivia", "Sophia",
                    "Ava", "Isabella", "Daniel", "Matthew", "Andrew", "Joshua", "Emily", "Sarah",
                    "Jessica", "Ashley", "Christopher", "Joseph", "Maria", "Carlos", "Wei", "Priya"]
USA_LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
                   "Rodriguez", "Martinez", "Wilson", "Anderson", "Taylor", "Thomas", "Lee", "Walker",
                   "Young", "King", "Wright", "Chen"]
USA_CITIES = ["New York", "San Francisco", "Austin", "Chicago", "Seattle", "Boston", "Denver",
               "Atlanta", "Dallas", "Portland"]
USA_OCCUPATIONS = ["Software Engineer", "Physician", "Attorney", "Small Business Owner",
                    "Federal Employee", "Marketing Director", "Teacher", "Financial Analyst",
                    "Consultant", "Product Manager"]

JOURNEYS = ["Retirement Planning", "Child Education", "Buy Home"]


@dataclass
class Holding:
    symbol: str
    name: str
    units: float
    buy_price: float
    current_price: float
    sector: str
    asset_class: str
    start_date: str = ""

    @property
    def cost_basis(self) -> float:
        return self.units * self.buy_price

    @property
    def market_value(self) -> float:
        return self.units * self.current_price

    @property
    def gain_loss(self) -> float:
        return self.market_value - self.cost_basis

    @property
    def gain_loss_pct(self) -> float:
        return (self.gain_loss / self.cost_basis * 100) if self.cost_basis else 0.0


@dataclass
class Goal:
    journey: str
    label: str
    target_amount: float
    target_year: int
    current_savings: float
    monthly_contribution: float
    extra: dict = field(default_factory=dict)


@dataclass
class Customer:
    id: int
    name: str
    age: int
    country: str
    city: str
    currency: str
    occupation: str
    annual_income: float
    monthly_expenses: float
    total_savings: float
    emergency_fund: float
    dependents: int
    marital_status: str
    tax_bracket: str
    risk_score: int
    risk_band: str
    holdings: list = field(default_factory=list)
    goals: list = field(default_factory=list)


def _make_holdings(rng: random.Random, current_year: int) -> list[Holding]:
    universe = US_INSTRUMENTS
    symbols = [s for s in universe.keys() if not s.startswith("CASH")]
    n = rng.randint(4, 7)
    chosen = rng.sample(symbols, min(n, len(symbols)))
    chosen.append("CASH_USD")  # always include a cash position

    holdings = []
    for sym in chosen:
        name, sector, asset_class, cur_price, _ret = universe[sym]
        # simulate a historical buy price with some noise vs current price
        drift = rng.uniform(-0.30, 0.20)
        buy_price = round(cur_price / (1 + drift), 2) if asset_class != "Cash" else 1.0
        units = rng.uniform(500, 5000) if asset_class == "Cash" else rng.uniform(2, 120)
        months_ago = rng.randint(2, 60)
        start_year = current_year - (months_ago // 12)
        start_month = ((12 - (months_ago % 12) - 1) % 12) + 1
        start_date = f"{start_year:04d}-{start_month:02d}-{rng.randint(1, 28):02d}"
        holdings.append(Holding(
            symbol=sym, name=name, units=round(units, 2), buy_price=buy_price,
            current_price=cur_price, sector=sector, asset_class=asset_class,
            start_date=start_date,
        ))
    return holdings


def _make_goals(rng: random.Random, age: int, current_year: int) -> list[Goal]:
    n_goals = rng.randint(1, 3)
    journeys = rng.sample(JOURNEYS, n_goals)
    goals = []
    for j in journeys:
        if j == "Retirement Planning":
            lo = max(age + 5, 55)
            hi = max(lo + 2, 67)
            target_age = rng.randint(lo, hi)
            years = target_age - age
            monthly_income_needed = rng.uniform(3000, 9000)
            corpus_target = monthly_income_needed * 12 * 22  # ~22 years post-retirement, 4.5% withdrawal approx
            goals.append(Goal(
                journey=j, label="Retirement Corpus",
                target_amount=round(corpus_target, -3),
                target_year=current_year + years,
                current_savings=round(rng.uniform(0.05, 0.35) * corpus_target, -2),
                monthly_contribution=round(rng.uniform(300, 1500), -1),
                extra={"target_retirement_age": target_age, "monthly_income_needed": round(monthly_income_needed, -2)},
            ))
        elif j == "Child Education":
            child_age = rng.randint(1, 14)
            years = max(18 - child_age, 1)
            cost_today = rng.uniform(40000, 120000)
            goals.append(Goal(
                journey=j, label="Child Education Fund",
                target_amount=round(cost_today, -2),
                target_year=current_year + years,
                current_savings=round(rng.uniform(0.05, 0.30) * cost_today, -2),
                monthly_contribution=round(rng.uniform(150, 800), -1),
                extra={"child_current_age": child_age},
            ))
        else:  # Buy Home
            years = rng.randint(2, 8)
            home_price = rng.uniform(300000, 900000)
            down_pct = rng.choice([10, 15, 20, 25])
            goals.append(Goal(
                journey=j, label="Home Down Payment",
                target_amount=round(home_price * down_pct / 100, -2),
                target_year=current_year + years,
                current_savings=round(rng.uniform(0.05, 0.40) * home_price * down_pct / 100, -2),
                monthly_contribution=round(rng.uniform(200, 1200), -1),
                extra={"home_price": round(home_price, -3), "down_payment_pct": down_pct},
            ))
    return goals


def _synthetic_risk_answers(rng: random.Random, age: int) -> list[int]:
    bias = 2 if age < 35 else (1 if age < 50 else 0)
    answers = []
    for _ in QUESTIONNAIRE:
        base = rng.randint(0, 3)
        answers.append(max(0, min(3, round((base + bias) / 2))))
    return answers


def _generate_customer(cid: int, rng: random.Random, current_year: int) -> Customer:
    first = rng.choice(USA_FIRST_NAMES)
    last = rng.choice(USA_LAST_NAMES)
    city = rng.choice(USA_CITIES)
    occupation = rng.choice(USA_OCCUPATIONS)
    currency = "USD"
    annual_income = round(rng.uniform(45000, 350000), -2)
    tax_bracket = rng.choice(["12%", "22%", "24%", "32%", "35%"])

    age = rng.randint(24, 62)
    dependents = rng.choice([0, 0, 1, 1, 2, 2, 3])
    marital_status = rng.choice(["Single", "Married", "Married", "Divorced"])
    monthly_expenses = round(annual_income / 12 * rng.uniform(0.35, 0.65), -1)
    total_savings = round(annual_income * rng.uniform(0.5, 4.0), -2)
    emergency_fund = round(monthly_expenses * rng.uniform(1.5, 8.0), -1)

    answers = _synthetic_risk_answers(rng, age)
    risk = compute_risk(answers, age, annual_income, dependents)

    holdings = _make_holdings(rng, current_year)
    goals = _make_goals(rng, age, current_year)

    name = f"{first} {last}"
    return Customer(
        id=cid, name=name, age=age, country="USA", city=city, currency=currency,
        occupation=occupation, annual_income=annual_income, monthly_expenses=monthly_expenses,
        total_savings=total_savings, emergency_fund=emergency_fund, dependents=dependents,
        marital_status=marital_status, tax_bracket=tax_bracket,
        risk_score=risk.risk_score, risk_band=risk.risk_band,
        holdings=holdings, goals=goals,
    )


def generate_customers(current_year: int = 2026, count: int = 100) -> list[Customer]:
    rng = random.Random(SEED)
    return [_generate_customer(cid, rng, current_year) for cid in range(1, count + 1)]


_CUSTOMERS_CACHE: list[Customer] | None = None


def all_customers() -> list[Customer]:
    global _CUSTOMERS_CACHE
    if _CUSTOMERS_CACHE is None:
        _CUSTOMERS_CACHE = generate_customers()
    return _CUSTOMERS_CACHE


def get_customer(customer_id: int) -> Customer | None:
    for c in all_customers():
        if c.id == customer_id:
            return c
    return None


def new_blank_customer(name: str, age: int) -> Customer:
    return Customer(
        id=0, name=name or "New Customer", age=age, country="USA",
        city="", currency="USD", occupation="", annual_income=0.0,
        monthly_expenses=0.0, total_savings=0.0, emergency_fund=0.0,
        dependents=0, marital_status="Single", tax_bracket="",
        risk_score=50, risk_band="Moderate", holdings=[], goals=[],
    )


# ---------------------------------------------------------------------------
# SQLite-backed "user memory" -- conversation & session persistence
# ---------------------------------------------------------------------------

def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS conversation_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            role TEXT,
            content TEXT,
            journey TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS agent_run_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            intent TEXT,
            agents_run TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS hitl_decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER,
            journey TEXT,
            option_label TEXT,
            model_name TEXT,
            decision TEXT,
            comment TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def init_db() -> None:
    conn = _connect()
    conn.close()


def log_message(customer_id: int, role: str, content: str, journey: str = "") -> None:
    conn = _connect()
    conn.execute(
        "INSERT INTO conversation_log (customer_id, role, content, journey) VALUES (?, ?, ?, ?)",
        (customer_id, role, content, journey),
    )
    conn.commit()
    conn.close()


def log_agent_run(customer_id: int, intent: str, agents_run: list[str]) -> None:
    conn = _connect()
    conn.execute(
        "INSERT INTO agent_run_log (customer_id, intent, agents_run) VALUES (?, ?, ?)",
        (customer_id, intent, ",".join(agents_run)),
    )
    conn.commit()
    conn.close()


def get_conversation_history(customer_id: int, limit: int = 50) -> list[dict]:
    conn = _connect()
    cur = conn.execute(
        "SELECT role, content, journey, created_at FROM conversation_log "
        "WHERE customer_id = ? ORDER BY id DESC LIMIT ?",
        (customer_id, limit),
    )
    rows = cur.fetchall()
    conn.close()
    return [{"role": r[0], "content": r[1], "journey": r[2], "created_at": r[3]} for r in reversed(rows)]


def log_decision(customer_id: int, journey: str, option_label: str, model_name: str,
                  decision: str, comment: str) -> None:
    """Record a human-in-the-loop Approve / Reject / Override decision on a
    recommendation option. `comment` is the required user response captured
    alongside the decision."""
    conn = _connect()
    conn.execute(
        "INSERT INTO hitl_decisions (customer_id, journey, option_label, model_name, decision, comment) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (customer_id, journey, option_label, model_name, decision, comment),
    )
    conn.commit()
    conn.close()


def get_decisions(customer_id: int, journey: str = "") -> list[dict]:
    conn = _connect()
    if journey:
        cur = conn.execute(
            "SELECT option_label, model_name, decision, comment, created_at FROM hitl_decisions "
            "WHERE customer_id = ? AND journey = ? ORDER BY id ASC",
            (customer_id, journey),
        )
    else:
        cur = conn.execute(
            "SELECT option_label, model_name, decision, comment, created_at FROM hitl_decisions "
            "WHERE customer_id = ? ORDER BY id ASC",
            (customer_id,),
        )
    rows = cur.fetchall()
    conn.close()
    return [{"option_label": r[0], "model_name": r[1], "decision": r[2], "comment": r[3], "created_at": r[4]}
            for r in rows]

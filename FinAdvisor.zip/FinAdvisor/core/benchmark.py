"""Benchmarking Engine: map model portfolio to a blended benchmark, compute
relative return, tracking difference, relative risk, and compare to the
broad market index (build spec section 6). US customers only."""
from __future__ import annotations

from dataclasses import dataclass

from core.market import BENCHMARK_BLEND_RETURNS, BROAD_MARKET_RETURN, BENCHMARK_COMPONENTS
from core.models import ModelPortfolio


@dataclass
class BenchmarkResult:
    model_name: str
    blended_benchmark_return: float
    portfolio_return: float
    relative_return: float          # portfolio - benchmark
    tracking_difference: float      # abs(portfolio - benchmark)
    portfolio_volatility: float
    relative_risk: float            # portfolio_vol - benchmark_vol (approx via model)
    broad_market_return: float
    vs_broad_market: float
    components: dict


# Approximate benchmark volatility by band (illustrative), used for relative risk
BENCHMARK_VOLATILITY = {
    "Conservative": 0.045,
    "Moderate": 0.075,
    "Growth": 0.115,
    "Aggressive": 0.155,
}


def compute_benchmark(model: ModelPortfolio, realized_portfolio_return: float | None = None) -> BenchmarkResult:
    band = model.name
    blended_return = BENCHMARK_BLEND_RETURNS[band]
    portfolio_return = realized_portfolio_return if realized_portfolio_return is not None else model.expected_return
    bench_vol = BENCHMARK_VOLATILITY[band]

    relative_return = portfolio_return - blended_return
    tracking_difference = abs(portfolio_return - blended_return)
    relative_risk = model.est_volatility - bench_vol
    vs_broad = portfolio_return - BROAD_MARKET_RETURN

    return BenchmarkResult(
        model_name=band,
        blended_benchmark_return=blended_return,
        portfolio_return=portfolio_return,
        relative_return=relative_return,
        tracking_difference=tracking_difference,
        portfolio_volatility=model.est_volatility,
        relative_risk=relative_risk,
        broad_market_return=BROAD_MARKET_RETURN,
        vs_broad_market=vs_broad,
        components=BENCHMARK_COMPONENTS,
    )

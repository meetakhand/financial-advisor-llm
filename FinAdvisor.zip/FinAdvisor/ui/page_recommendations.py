"""Recommendations page: prioritized rebalancing actions, with human-in-the-loop
override — an advisor/user can pick a different model band or hand-edit the
target allocation, and the Recommendation Engine recomputes drift/fit/actions."""
from __future__ import annotations

import streamlit as st

from core.models import MODEL_PORTFOLIOS, ASSET_CLASSES
from agents.recommend_agent import run_recommendation, apply_model_override, apply_custom_allocation_override
from ui.formatting import format_pct
from ui.dashboard_components import render_decision_log
from ui.session import get_active_customer, require_plan


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Recommendations")
    st.caption("The primary way to review the 3 AI investment options with Approve / Reject / "
               "Override is the **FinAdvisor** chat panel. This page is a detail view / advisor "
               "override console for the currently active recommendation.")
    if not require_plan():
        return

    result = st.session_state.pipeline_result
    rb = result.rec_bundle

    st.markdown(f"### AI-Suggested Model: **{rb.ai_suggested_model}**")
    if rb.is_overridden:
        st.warning(f"Human override active: {rb.override_note}")
    st.markdown(f"**Active model driving recommendations: {rb.active_model}**")

    st.markdown("#### Prioritized Actions")
    if rb.result.needs_rebalancing:
        for line in rb.text_recommendations:
            priority = "🔴" if "[High]" in line else ("🟡" if "[Medium]" in line else "🟢")
            st.markdown(f"{priority} {line}")
    else:
        st.success(rb.text_recommendations[0])

    st.divider()
    st.markdown("## Human-in-the-Loop Review")
    st.caption("An advisor (or the customer) can override the AI's suggested model or "
               "hand-adjust the target allocation. All overrides are logged in the report.")

    tab1, tab2 = st.tabs(["Override Model Band", "Custom Target Allocation"])

    with tab1:
        with st.form("override_model_form"):
            current_allocation = rb.result.current_allocation
            choice = st.selectbox("Choose a model band to apply instead", list(MODEL_PORTFOLIOS.keys()),
                                   index=list(MODEL_PORTFOLIOS.keys()).index(rb.active_model)
                                   if rb.active_model in MODEL_PORTFOLIOS else 1)
            submitted = st.form_submit_button("Apply Model Override", type="primary")
            if submitted:
                new_bundle = apply_model_override(current_allocation, rb.ai_suggested_model, choice)
                result.rec_bundle = new_bundle
                st.session_state.pipeline_result = result
                st.success(f"Applied override: active model is now **{choice}**.")
                st.rerun()

    with tab2:
        with st.form("override_custom_form"):
            st.caption("Enter a custom target allocation (%). Values are normalized to sum to 100%.")
            custom_vals = {}
            cols = st.columns(len(ASSET_CLASSES))
            for col, ac in zip(cols, ASSET_CLASSES):
                with col:
                    default_val = rb.result.target_allocation.get(ac, 0.0)
                    custom_vals[ac] = st.number_input(ac, min_value=0.0, max_value=100.0,
                                                        value=float(default_val), step=1.0, key=f"custom_{ac}")
            submitted2 = st.form_submit_button("Apply Custom Allocation", type="primary")
            if submitted2:
                new_bundle = apply_custom_allocation_override(rb.result.current_allocation,
                                                                rb.ai_suggested_model, custom_vals)
                result.rec_bundle = new_bundle
                st.session_state.pipeline_result = result
                st.success("Applied custom target allocation override.")
                st.rerun()

    if rb.is_overridden and st.button("Revert to AI Suggestion"):
        reset_bundle = run_recommendation(rb.ai_suggested_model, rb.result.current_allocation)
        result.rec_bundle = reset_bundle
        st.session_state.pipeline_result = result
        st.rerun()

    st.divider()
    render_decision_log(customer, result.journey)

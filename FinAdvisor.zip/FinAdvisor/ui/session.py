"""Session helpers: resolve the active customer, shared across pages."""
from __future__ import annotations

import streamlit as st

from core.data import get_customer


def get_active_customer():
    cid = st.session_state.get("customer_id")
    if cid is None:
        return None
    if st.session_state.get("is_new_customer"):
        return st.session_state.get("new_customer")
    return get_customer(cid)


def require_customer() -> bool:
    """Returns True if a customer is loaded; otherwise shows a guidance message."""
    if get_active_customer() is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return False
    return True


def require_plan() -> bool:
    if st.session_state.get("pipeline_result") is None:
        st.info("No plan generated yet. Go to **FinAdvisor** and complete a journey "
                 "(Retirement Planning, Child Education, or Buy Home) to generate one.")
        return False
    return True

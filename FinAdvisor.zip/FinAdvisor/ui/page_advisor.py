"""FinAdvisor page: the AI-native wealth management chat experience.

Everything happens inside the chat panel: guided goal/risk data collection,
an embedded live dashboard, three AI-generated investment options, and a
human-in-the-loop Approve / Reject / Override review for each option (every
decision requires the human to type a response, which is logged and shown
in the Report). Free-text Financial Q&A via RAG is available at any point.
"""
from __future__ import annotations

from datetime import date

import streamlit as st

from core.data import log_message, log_decision
from core.models import ASSET_CLASSES, MODEL_PORTFOLIOS
from core.risk import QUESTIONNAIRE
from agents.orchestrator import run_pipeline, PLANNING_JOURNEYS
from agents.advisor import intro_message, answer_financial_question
from agents.intent import classify_intent
from agents.recommend_agent import (
    generate_investment_options, apply_model_override, apply_custom_allocation_override,
)
from agents.portfolio_agent import (
    CATEGORY_ORDER, CATEGORY_DESCRIPTIONS, build_holdings_from_categories, default_category_totals,
)
from agents.report_agent import build_markdown_report
from ui.session import get_active_customer
from ui.dashboard_components import render_full_dashboard
from ui.charts import allocation_donut, risk_gauge, fit_gauge, current_vs_target_bars, benchmark_growth_line
from ui.formatting import format_pct

CURRENT_YEAR = date.today().year

DECISION_BADGE = {"Approve": "✅ Approved", "Reject": "❌ Rejected", "Override": "✏️ Overridden"}
DECISION_ICON = {"Approve": "✅", "Reject": "❌", "Override": "✏️"}

RISK_BAND_DESCRIPTIONS = {
    "Conservative": "You prioritize protecting what you have over maximizing growth. Expect smaller "
                    "ups and downs, and lower long-run growth in exchange for that stability.",
    "Moderate": "You're comfortable with a balanced mix of growth and safety — some ups and downs "
                "in pursuit of steadier long-term growth.",
    "Growth": "You're comfortable taking on meaningful market swings in pursuit of stronger "
              "long-term growth.",
    "Aggressive": "You're comfortable with significant volatility in pursuit of maximum long-term "
                  "growth — the biggest swings, but the highest growth potential.",
}


def _find_goal(customer, journey):
    for g in customer.goals:
        if g.journey == journey:
            return g
    return None


def _push(role, content, journey="", msg_type="text"):
    st.session_state.chat_history.append({"role": role, "type": msg_type, "content": content})
    customer = get_active_customer()
    if customer and customer.id:
        log_text = content if msg_type == "text" else f"[{msg_type} panel shown]"
        log_message(customer.id, role, log_text, journey)


def _next_msg_id():
    st.session_state.msg_counter = st.session_state.get("msg_counter", 0) + 1
    return f"msg{st.session_state.msg_counter}"


def _ensure_state():
    st.session_state.setdefault("chat_history", [])
    st.session_state.setdefault("active_journey", None)
    st.session_state.setdefault("goal_inputs", {})
    st.session_state.setdefault("risk_answers", None)
    st.session_state.setdefault("pipeline_result", None)
    st.session_state.setdefault("ai_suggested_model", None)
    st.session_state.setdefault("awaiting_portfolio_input", False)
    st.session_state.setdefault("awaiting_risk_quiz", False)
    st.session_state.setdefault("portfolio_inputs", None)
    st.session_state.setdefault("custom_holdings", None)
    st.session_state.setdefault("hitl_decisions", {})
    st.session_state.setdefault("pending_hitl", None)


def _journey_cards(customer):
    st.markdown("**What would you like to explore?**")
    cols = st.columns(4)
    labels = [
        ("🏖️ Retirement Planning", "Retirement Planning"),
        ("🎓 Child Education", "Child Education"),
        ("🏠 Buy a Home", "Buy Home"),
        ("💬 Financial Q&A", "Financial Q&A"),
    ]
    for col, (label, journey) in zip(cols, labels):
        with col:
            if st.button(label, use_container_width=True, key=f"card_{journey}"):
                st.session_state.active_journey = journey
                st.session_state.pipeline_result = None
                if journey == "Financial Q&A":
                    _push("assistant", "Great — ask me anything about investing, taxes, "
                                        "SIPs, retirement accounts, or your portfolio.")
                else:
                    _push("assistant", f"Let's set up your **{journey}** goal. "
                                        f"Fill in the details below.", journey)
                st.rerun()


def _retirement_form(customer):
    existing = _find_goal(customer, "Retirement Planning")
    with st.form("retirement_form"):
        st.markdown("#### Retirement Planning — Goal Setting")
        c1, c2 = st.columns(2)
        with c1:
            current_age = st.number_input("Current age", 18, 80, value=customer.age)
            target_age = st.number_input("Target retirement age", int(current_age) + 1, 90,
                                          value=int(existing.extra.get("target_retirement_age", 62)) if existing else 62)
            desired_income = st.number_input(
                f"Desired monthly income in retirement ({customer.currency})", min_value=0.0,
                value=float(existing.extra.get("monthly_income_needed", 3000 if customer.currency == "USD" else 100000)) if existing else (3000.0 if customer.currency == "USD" else 100000.0),
                step=100.0,
            )
        with c2:
            current_savings = st.number_input(
                f"Current retirement savings ({customer.currency})", min_value=0.0,
                value=float(existing.current_savings if existing else customer.total_savings), step=100.0,
            )
            monthly_contribution = st.number_input(
                f"Monthly contribution ({customer.currency})", min_value=0.0,
                value=float(existing.monthly_contribution) if existing else 500.0, step=50.0,
            )
        submitted = st.form_submit_button("Continue", type="primary")
        if submitted:
            st.session_state.goal_inputs = {
                "current_age": int(current_age), "target_retirement_age": int(target_age),
                "desired_monthly_income": desired_income, "current_savings": current_savings,
                "monthly_contribution": monthly_contribution,
            }
            summary = (f"Retirement goal: retire at {target_age}, need {customer.currency} "
                       f"{desired_income:,.0f}/month, starting from {customer.currency} "
                       f"{current_savings:,.0f} with {customer.currency} {monthly_contribution:,.0f}/month contributions.")
            _push("user", summary, "Retirement Planning")
            st.session_state.awaiting_portfolio_input = True
            st.rerun()


def _child_education_form(customer):
    existing = _find_goal(customer, "Child Education")
    with st.form("child_education_form"):
        st.markdown("#### Child Education — Goal Setting")
        c1, c2 = st.columns(2)
        with c1:
            child_age = st.number_input("Child's current age", 0, 17,
                                         value=int(existing.extra.get("child_current_age", 5)) if existing else 5)
            college_age = st.number_input("Age when college starts", int(child_age) + 1, 25, value=18)
            target_cost = st.number_input(
                f"Target education cost, today's value ({customer.currency})", min_value=0.0,
                value=float(existing.target_amount) if existing else (60000.0 if customer.currency == "USD" else 2000000.0),
                step=1000.0,
            )
        with c2:
            current_savings = st.number_input(
                f"Current savings for this goal ({customer.currency})", min_value=0.0,
                value=float(existing.current_savings) if existing else 0.0, step=100.0,
            )
            monthly_contribution = st.number_input(
                f"Monthly contribution ({customer.currency})", min_value=0.0,
                value=float(existing.monthly_contribution) if existing else 300.0, step=50.0,
            )
        submitted = st.form_submit_button("Continue", type="primary")
        if submitted:
            st.session_state.goal_inputs = {
                "child_current_age": int(child_age), "target_cost_today": target_cost,
                "current_savings": current_savings, "monthly_contribution": monthly_contribution,
            }
            summary = (f"Child education goal: child is {child_age}, college at {college_age}, "
                       f"target cost {customer.currency} {target_cost:,.0f} today, starting from "
                       f"{customer.currency} {current_savings:,.0f} with {customer.currency} "
                       f"{monthly_contribution:,.0f}/month.")
            _push("user", summary, "Child Education")
            st.session_state.awaiting_portfolio_input = True
            st.rerun()


def _buy_home_form(customer):
    existing = _find_goal(customer, "Buy Home")
    with st.form("buy_home_form"):
        st.markdown("#### Buy a Home — Goal Setting")
        c1, c2 = st.columns(2)
        with c1:
            home_price = st.number_input(
                f"Target home price ({customer.currency})", min_value=0.0,
                value=float(existing.extra.get("home_price", 400000)) if existing else (400000.0 if customer.currency == "USD" else 8000000.0),
                step=1000.0,
            )
            down_pct = st.slider("Down payment %", 5, 30,
                                  value=int(existing.extra.get("down_payment_pct", 20)) if existing else 20)
            target_year = st.number_input("Target purchase year", CURRENT_YEAR + 1, CURRENT_YEAR + 30,
                                           value=int(existing.target_year) if existing else CURRENT_YEAR + 4)
        with c2:
            current_savings = st.number_input(
                f"Current savings toward down payment ({customer.currency})", min_value=0.0,
                value=float(existing.current_savings) if existing else 0.0, step=100.0,
            )
            monthly_capacity = st.number_input(
                f"Monthly saving capacity ({customer.currency})", min_value=0.0,
                value=float(existing.monthly_contribution) if existing else 500.0, step=50.0,
            )
        submitted = st.form_submit_button("Continue", type="primary")
        if submitted:
            st.session_state.goal_inputs = {
                "home_price": home_price, "down_payment_pct": down_pct,
                "target_purchase_year": int(target_year), "current_year": CURRENT_YEAR,
                "current_savings": current_savings, "monthly_saving_capacity": monthly_capacity,
            }
            summary = (f"Buy Home goal: {customer.currency} {home_price:,.0f} home by {target_year}, "
                       f"{down_pct}% down payment, starting from {customer.currency} {current_savings:,.0f} "
                       f"saving {customer.currency} {monthly_capacity:,.0f}/month.")
            _push("user", summary, "Buy Home")
            st.session_state.awaiting_portfolio_input = True
            st.rerun()


def _portfolio_form(customer):
    st.markdown("#### Current Portfolio")
    st.caption("Tell me what you currently hold across these categories, and roughly when you "
               "started each — this becomes the starting point for your recommendation.")
    defaults = default_category_totals(customer)
    with st.form("portfolio_form"):
        inputs = {}
        for category in CATEGORY_ORDER:
            st.markdown(f"**{category}**")
            st.caption(CATEGORY_DESCRIPTIONS[category])
            c1, c2 = st.columns([2, 1])
            with c1:
                amount = st.number_input(
                    f"{category} — current value ({customer.currency})", min_value=0.0,
                    value=float(defaults[category]["amount"]), step=100.0, key=f"port_amt_{category}",
                )
            with c2:
                default_date = date.fromisoformat(defaults[category]["start_date"])
                start = st.date_input(f"{category} start date", value=default_date,
                                       max_value=date.today(), key=f"port_date_{category}")
            inputs[category] = {"amount": amount, "start_date": start.isoformat()}
        submitted = st.form_submit_button("Continue to Risk Profiling", type="primary")
        if submitted:
            st.session_state.portfolio_inputs = inputs
            st.session_state.custom_holdings = build_holdings_from_categories(inputs)
            total = sum(v["amount"] for v in inputs.values())
            lines = [f"- **{c}**: {customer.currency} {v['amount']:,.0f} (since {v['start_date']})"
                     for c, v in inputs.items() if v["amount"] > 0]
            summary = ("Current portfolio:\n\n" + ("\n".join(lines) if lines else "No current holdings reported.")
                       + f"\n\n**Total: {customer.currency} {total:,.0f}**")
            _push("user", summary, st.session_state.active_journey)
            st.session_state.awaiting_portfolio_input = False
            st.session_state.awaiting_risk_quiz = True
            st.rerun()


def _risk_quiz(customer):
    st.markdown("#### Quick Risk Profiling")
    st.caption("A few plain-language questions so FinAdvisor can recommend a suitable model "
               "portfolio — there are no wrong answers, just what's true for you.")
    with st.form("risk_quiz_form"):
        answers = []
        for q in QUESTIONNAIRE:
            choice = st.radio(q["question"], options=range(len(q["options"])),
                               format_func=lambda i, q=q: q["options"][i][0], key=f"risk_{q['id']}")
            answers.append(q["options"][choice][1])
        submitted = st.form_submit_button("See My Plan", type="primary")
        if submitted:
            st.session_state.risk_answers = answers
            _push("user", "Completed the risk questionnaire.", st.session_state.active_journey)

            result = run_pipeline(customer, st.session_state.active_journey, st.session_state.goal_inputs,
                                   risk_answer_points=answers,
                                   holdings_override=st.session_state.get("custom_holdings"))
            st.session_state.pipeline_result = result
            st.session_state.ai_suggested_model = result.risk_result.risk_band
            st.session_state.awaiting_risk_quiz = False

            rr = result.risk_result
            _push("assistant", "Here's what that tells me about your risk profile:", result.journey)
            _push("assistant", rr, result.journey, msg_type="risk")

            gp = result.goal_plan
            msg = (
                f"And here's your **{result.journey}** plan:\n\n"
                f"- Target amount: {customer.currency} {gp.target_amount_future:,.0f} in {gp.years:.0f} years\n"
                f"- Required monthly SIP: **{customer.currency} {gp.required_monthly_sip:,.0f}**\n"
                f"- Success probability: **{gp.success_prob}%**\n\n"
                f"Here's a live snapshot of where things stand today:"
            )
            _push("assistant", msg, result.journey)
            _push("assistant", result, result.journey, msg_type="dashboard")

            _push("assistant", "Here's how the model portfolios compare, and how your active "
                                "recommendation fits your current portfolio:", result.journey)
            _push("assistant", result, result.journey, msg_type="model_fit")

            _push("assistant", "And here's how that model has tracked against the market:", result.journey)
            _push("assistant", result, result.journey, msg_type="benchmark")

            current_allocation = result.rec_bundle.result.current_allocation
            options = generate_investment_options(rr.risk_band, current_allocation)
            options_payload = {
                "msg_id": _next_msg_id(), "journey": result.journey,
                "current_allocation": current_allocation, "options": options,
            }
            _push("assistant",
                  "Based on your profile, here are **3 investment options** for your review. "
                  "Approve, reject, or override each one — I'll ask you to explain your choice.",
                  result.journey)
            _push("assistant", options_payload, result.journey, msg_type="options")
            st.rerun()


def _finalize_decision(customer, payload, option, decision, comment, custom_vals=None):
    journey = payload["journey"]
    key = f"{payload['msg_id']}:{option.label}"
    ai_suggested = st.session_state.ai_suggested_model or option.model.name
    current_allocation = payload["current_allocation"]

    log_decision(customer.id, journey, option.label, option.model.name, decision, comment)
    st.session_state.hitl_decisions[key] = {
        "decision": decision, "comment": comment, "model_name": option.model.name,
    }

    result = st.session_state.pipeline_result
    if decision == "Approve" and result is not None:
        new_bundle = apply_model_override(current_allocation, ai_suggested, option.model.name)
        result.rec_bundle = new_bundle
        st.session_state.pipeline_result = result
        note = f"You **approved {option.label} ({option.model.name})**.\n\n> {comment}\n\nThis is now your active recommendation."
    elif decision == "Override" and result is not None:
        new_bundle = apply_custom_allocation_override(current_allocation, ai_suggested, custom_vals or option.model.allocation)
        new_bundle.override_note = (f"Advisor overrode {option.label} ({option.model.name}) with a custom "
                                     f"allocation. Reason: {comment}")
        result.rec_bundle = new_bundle
        st.session_state.pipeline_result = result
        note = f"You **overrode {option.label} ({option.model.name})** with a custom allocation.\n\n> {comment}\n\nThis is now your active recommendation."
    else:
        note = f"You **rejected {option.label} ({option.model.name})**.\n\n> {comment}"

    _push("assistant", note, journey)
    st.session_state.pending_hitl = None


def _render_options_message(customer, payload):
    for option in payload["options"]:
        key = f"{payload['msg_id']}:{option.label}"
        existing = st.session_state.hitl_decisions.get(key)
        pending = st.session_state.get("pending_hitl")
        is_pending = pending is not None and pending.get("msg_id") == payload["msg_id"] and pending.get("opt_label") == option.label

        with st.container(border=True):
            star = " ⭐ AI Suggested" if option.is_ai_suggested else ""
            st.markdown(f"**{option.label}: {option.model.name}**{star}")
            st.caption(option.rationale)
            c1, c2 = st.columns([1, 1])
            with c1:
                st.plotly_chart(allocation_donut(option.model.allocation, option.model.name),
                                 use_container_width=True, key=f"opt_chart_{key}")
            with c2:
                st.metric("Fit vs Current Portfolio", f"{option.result.fit_score:.0f}/100")
                st.metric("Turnover Needed", f"{option.result.turnover:.1f}%")
                st.caption(f"Exp. return ≈ {option.model.expected_return*100:.1f}% · "
                           f"Volatility ≈ {option.model.est_volatility*100:.1f}%")

            if existing:
                st.success(f"{DECISION_BADGE[existing['decision']]} — \"{existing['comment']}\"")
                continue

            if not is_pending:
                b1, b2, b3 = st.columns(3)
                if b1.button("✅ Approve", key=f"approve_{key}", use_container_width=True):
                    st.session_state.pending_hitl = {"msg_id": payload["msg_id"], "opt_label": option.label, "decision": "Approve"}
                    st.rerun()
                if b2.button("❌ Reject", key=f"reject_{key}", use_container_width=True):
                    st.session_state.pending_hitl = {"msg_id": payload["msg_id"], "opt_label": option.label, "decision": "Reject"}
                    st.rerun()
                if b3.button("✏️ Override", key=f"override_{key}", use_container_width=True):
                    st.session_state.pending_hitl = {"msg_id": payload["msg_id"], "opt_label": option.label, "decision": "Override"}
                    st.rerun()
            else:
                decision = pending["decision"]
                st.info(f"{DECISION_ICON[decision]} **{decision} — {option.label}**: please explain your response below.")
                with st.form(f"hitl_form_{key}"):
                    comment = st.text_area("Your response (required)", key=f"comment_{key}",
                                            placeholder="Why are you approving / rejecting / overriding this option?")
                    custom_vals = None
                    if decision == "Override":
                        st.caption("Adjust the target allocation (%) — normalized to sum to 100%.")
                        custom_vals = {}
                        cols = st.columns(len(ASSET_CLASSES))
                        for c, ac in zip(cols, ASSET_CLASSES):
                            with c:
                                custom_vals[ac] = st.number_input(
                                    ac, min_value=0.0, max_value=100.0,
                                    value=float(option.model.allocation.get(ac, 0.0)), step=1.0,
                                    key=f"customval_{key}_{ac}",
                                )
                    fc1, fc2 = st.columns([1, 1])
                    submitted = fc1.form_submit_button("Submit Response", type="primary", use_container_width=True)
                    cancelled = fc2.form_submit_button("Cancel", use_container_width=True)
                    if submitted:
                        if not comment or not comment.strip():
                            st.error("A response is required before submitting.")
                        else:
                            _finalize_decision(customer, payload, option, decision, comment.strip(), custom_vals)
                            st.rerun()
                    elif cancelled:
                        st.session_state.pending_hitl = None
                        st.rerun()


def _render_risk_message(risk_result, key_prefix=""):
    col1, col2 = st.columns([1, 1])
    with col1:
        st.plotly_chart(risk_gauge(risk_result.risk_score, risk_result.risk_band),
                         use_container_width=True, key=f"{key_prefix}riskmsg_{id(risk_result)}")
    with col2:
        st.markdown(f"### {risk_result.risk_band}")
        st.markdown(RISK_BAND_DESCRIPTIONS.get(risk_result.risk_band, ""))
        st.caption(f"**Risk tolerance** {risk_result.tolerance:.0f}/100 — how you feel about market swings.")
        st.caption(f"**Risk capacity** {risk_result.capacity:.0f}/100 — how much risk you can financially afford "
                   f"(based on time horizon, income, and dependents).")
        st.caption(f"Combined score: **{risk_result.risk_score}/100**")


def _render_model_fit_message(pipeline_result, key_prefix=""):
    rb = pipeline_result.rec_bundle
    st.markdown("#### Model Portfolios & Fit")
    st.caption("The four model portfolios FinAdvisor chooses between, and how your active "
               "recommendation fits against your current portfolio.")
    cols = st.columns(4)
    for col, (name, model) in zip(cols, MODEL_PORTFOLIOS.items()):
        with col:
            star = " ⭐" if name == rb.active_model else ""
            st.markdown(f"**{name}{star}**")
            st.plotly_chart(allocation_donut(model.allocation, name), use_container_width=True,
                             key=f"{key_prefix}mf_{name}_{id(pipeline_result)}")
            st.caption(f"Return ≈ {model.expected_return*100:.1f}% · Vol ≈ {model.est_volatility*100:.1f}%")
    st.divider()
    st.markdown(f"**Active model: {rb.active_model}**")
    col1, col2 = st.columns([1, 1])
    with col1:
        st.plotly_chart(current_vs_target_bars(rb.result.current_allocation, rb.result.target_allocation),
                         use_container_width=True, key=f"{key_prefix}mfcvt_{id(pipeline_result)}")
    with col2:
        st.plotly_chart(fit_gauge(rb.result.fit_score), use_container_width=True,
                         key=f"{key_prefix}mffit_{id(pipeline_result)}")
        st.metric("Turnover Needed", f"{rb.result.turnover:.1f}%")


def _render_benchmark_message(pipeline_result, key_prefix=""):
    bm = pipeline_result.benchmark_result
    years = max(int(round(pipeline_result.goal_plan.years)), 5) if pipeline_result.goal_plan else 10
    st.markdown(f"#### Benchmarking — {bm.model_name} Model")
    st.caption(f"Projected across your **{years}-year** goal horizon against a blended benchmark "
               f"and the S&P 500. Illustrative — compounds each series' 12-month return flat over time.")
    st.plotly_chart(
        benchmark_growth_line(bm.portfolio_return, bm.blended_benchmark_return, bm.broad_market_return,
                               years=years, labels=(f"{bm.model_name} Model", "Blended Benchmark", "S&P 500")),
        use_container_width=True, key=f"{key_prefix}bmline_{id(pipeline_result)}",
    )
    c1, c2, c3 = st.columns(3)
    c1.metric("Relative Return vs Benchmark", format_pct(bm.relative_return * 100, signed=True))
    c2.metric("Tracking Difference", format_pct(bm.tracking_difference * 100))
    c3.metric("vs Broad Market (S&P 500)", format_pct(bm.vs_broad_market * 100, signed=True))


def _render_report_message(customer, pipeline_result, key_prefix=""):
    result = pipeline_result
    report_md = build_markdown_report(
        customer, result.journey, result.goal_plan, result.risk_result, result.model,
        result.portfolio_analysis, result.benchmark_result, result.rec_bundle,
    )
    st.markdown(report_md)
    st.download_button(
        "Download Report (Markdown)", data=report_md,
        file_name=f"nexwealth_{customer.name.replace(' ', '_')}_{result.journey.replace(' ', '_')}.md",
        mime="text/markdown", key=f"{key_prefix}dl_{id(pipeline_result)}",
    )


def _chat_transcript(customer):
    for m in st.session_state.chat_history:
        with st.chat_message(m["role"]):
            if m["type"] == "text":
                st.markdown(m["content"])
            elif m["type"] == "risk":
                _render_risk_message(m["content"], key_prefix=f"chat_{id(m)}_")
            elif m["type"] == "dashboard":
                render_full_dashboard(customer, pipeline_result=m["content"], compact=True,
                                       key_prefix=f"chatdash_{id(m)}_")
            elif m["type"] == "model_fit":
                _render_model_fit_message(m["content"], key_prefix=f"chatmf_{id(m)}_")
            elif m["type"] == "benchmark":
                _render_benchmark_message(m["content"], key_prefix=f"chatbm_{id(m)}_")
            elif m["type"] == "options":
                _render_options_message(customer, m["content"])
            elif m["type"] == "report":
                _render_report_message(customer, m["content"], key_prefix=f"chatrep_{id(m)}_")


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    _ensure_state()

    st.title("FinAdvisor")
    st.caption("💠 **AI-Native Wealth Management Experience** — plan, review, and approve "
               "investment decisions right here in chat.")
    st.caption(f"Chatting as **{customer.name}** · {customer.country} · {customer.currency}")

    if not st.session_state.chat_history:
        _push("assistant", intro_message(customer.name))

    _journey_cards(customer)
    st.divider()
    _chat_transcript(customer)

    if st.session_state.pipeline_result is not None:
        if st.button("📄 Generate Full Report", key="gen_report_btn"):
            result = st.session_state.pipeline_result
            _push("assistant", "Here's your full report, including the human-in-the-loop decision log:",
                  result.journey)
            _push("assistant", result, result.journey, msg_type="report")
            st.rerun()

    journey = st.session_state.active_journey
    if journey in PLANNING_JOURNEYS and st.session_state.pipeline_result is None:
        if st.session_state.awaiting_portfolio_input:
            _portfolio_form(customer)
        elif st.session_state.awaiting_risk_quiz:
            _risk_quiz(customer)
        else:
            if journey == "Retirement Planning":
                _retirement_form(customer)
            elif journey == "Child Education":
                _child_education_form(customer)
            elif journey == "Buy Home":
                _buy_home_form(customer)

    user_text = st.chat_input("Ask FinAdvisor a financial question...")
    if user_text:
        _push("user", user_text, journey or "Financial Q&A")
        detected = classify_intent(user_text, active_journey=journey or "")
        if detected in PLANNING_JOURNEYS and detected != journey:
            st.session_state.active_journey = detected
            st.session_state.pipeline_result = None
            st.session_state.awaiting_risk_quiz = False
            _push("assistant", f"Sure — let's set up your **{detected}** goal below.", detected)
        else:
            with st.spinner("FinAdvisor is thinking..."):
                result = answer_financial_question(user_text, customer)
            _push("assistant", result["answer"], "Financial Q&A")
        st.rerun()

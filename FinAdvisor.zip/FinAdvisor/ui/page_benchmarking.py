"""Benchmarking page: portfolio vs blended benchmark vs broad market index,
visualized as a growth-over-time line chart across the goal's own horizon."""
from __future__ import annotations

import streamlit as st

from ui.charts import benchmark_growth_line, benchmark_line
from ui.formatting import format_pct
from ui.session import get_active_customer, require_plan


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Benchmarking")
    if not require_plan():
        return

    result = st.session_state.pipeline_result
    bm = result.benchmark_result
    years = max(int(round(result.goal_plan.years)), 5) if result.goal_plan else 10

    broad_label = "S&P 500"
    st.markdown(f"Model **{bm.model_name}** benchmarked against a blended index "
                f"(equity/international/bond/gold weighted to match the model) and the broad "
                f"market ({broad_label}), projected across your **{years}-year** goal horizon.")

    st.plotly_chart(
        benchmark_growth_line(bm.portfolio_return, bm.blended_benchmark_return, bm.broad_market_return,
                               years=years, labels=(f"{bm.model_name} Model", "Blended Benchmark", broad_label)),
        use_container_width=True,
    )

    c1, c2, c3 = st.columns(3)
    c1.metric("Relative Return vs Benchmark", format_pct(bm.relative_return * 100, signed=True))
    c2.metric("Tracking Difference", format_pct(bm.tracking_difference * 100))
    c3.metric("Relative Risk (Volatility Δ)", format_pct(bm.relative_risk * 100, signed=True))

    st.metric(f"vs Broad Market ({broad_label})", format_pct(bm.vs_broad_market * 100, signed=True))

    with st.expander("12-month snapshot (bar view)"):
        st.plotly_chart(
            benchmark_line(bm.portfolio_return, bm.blended_benchmark_return, bm.broad_market_return,
                           labels=(f"{bm.model_name} Model", "Blended Benchmark", broad_label)),
            use_container_width=True,
        )

    st.markdown("### Benchmark Components")
    for ac, idx in bm.components.items():
        st.markdown(f"- **{ac}** → {idx}")

    st.caption("Illustrative figures — the growth line compounds each series' 12-month return flat "
               "across the horizon, not a real historical backtest. Swap in a live feed (Alpha "
               "Vantage / FRED) via core/market.py for production use.")

"""Model Portfolios & Fit page: the four model portfolios, current-vs-target
bars, drift table, and fit gauge for the active plan."""
from __future__ import annotations

import streamlit as st
import pandas as pd

from core.models import MODEL_PORTFOLIOS
from ui.charts import allocation_donut, current_vs_target_bars, drift_bar, fit_gauge
from ui.session import get_active_customer, require_plan


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Model Portfolios & Fit")

    st.markdown("### The Four Model Portfolios")
    cols = st.columns(4)
    for col, (name, model) in zip(cols, MODEL_PORTFOLIOS.items()):
        with col:
            st.markdown(f"**{name}**")
            st.plotly_chart(allocation_donut(model.allocation, name), use_container_width=True)
            st.caption(f"Exp. return ≈ {model.expected_return*100:.1f}% · Volatility ≈ {model.est_volatility*100:.1f}%")

    st.divider()
    if not require_plan():
        return

    result = st.session_state.pipeline_result
    rb = result.rec_bundle
    st.markdown(f"### Active Plan: {result.journey}")
    st.markdown(f"AI-suggested model: **{rb.ai_suggested_model}** · Active model: **{rb.active_model}**"
                + (" _(human override applied)_" if rb.is_overridden else ""))

    col1, col2 = st.columns(2)
    with col1:
        st.plotly_chart(current_vs_target_bars(rb.result.current_allocation, rb.result.target_allocation),
                         use_container_width=True)
    with col2:
        st.plotly_chart(fit_gauge(rb.result.fit_score), use_container_width=True)

    st.markdown("### Drift")
    st.plotly_chart(drift_bar(rb.result.drift), use_container_width=True)

    df = pd.DataFrame([
        {"Asset Class": ac, "Current %": rb.result.current_allocation.get(ac, 0),
         "Target %": rb.result.target_allocation.get(ac, 0), "Drift": rb.result.drift.get(ac, 0)}
        for ac in rb.result.target_allocation
    ])
    st.dataframe(df, use_container_width=True, hide_index=True)
    st.caption(f"Turnover: {rb.result.turnover:.1f}% · Fit score: {rb.result.fit_score:.1f}/100")

"""Risk Profile page: standalone questionnaire -> score gauge -> recommended model.

Independent of the FinAdvisor journey flow, so a user/advisor can (re)assess
risk profile at any time.
"""
from __future__ import annotations

import streamlit as st

from core.risk import QUESTIONNAIRE
from agents.risk_agent import run_risk_profiling
from ui.charts import risk_gauge, allocation_donut
from ui.session import get_active_customer


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Risk Profile")
    st.caption("Risk Score = 0.6 × Tolerance + 0.4 × Capacity. Bands: <35 Conservative, "
               "35–54 Moderate, 55–74 Growth, 75+ Aggressive.")

    st.markdown(f"**On file for {customer.name}:** Risk Score **{customer.risk_score}**/100 "
                f"→ **{customer.risk_band}**")
    st.plotly_chart(risk_gauge(customer.risk_score, customer.risk_band), use_container_width=True)

    st.divider()
    st.markdown("### Retake the Risk Questionnaire")
    with st.form("standalone_risk_quiz"):
        answers = []
        for q in QUESTIONNAIRE:
            choice = st.radio(q["question"], options=range(len(q["options"])),
                               format_func=lambda i, q=q: q["options"][i][0], key=f"std_risk_{q['id']}")
            answers.append(q["options"][choice][1])
        submitted = st.form_submit_button("Recalculate", type="primary")
        if submitted:
            result, model = run_risk_profiling(answers, customer.age, customer.annual_income,
                                                 customer.dependents)
            st.session_state.standalone_risk_result = result
            st.session_state.standalone_model = model

    if st.session_state.get("standalone_risk_result"):
        result = st.session_state.standalone_risk_result
        model = st.session_state.standalone_model
        st.success(f"New Risk Score: **{result.risk_score}/100** → **{result.risk_band}** "
                    f"(Tolerance {result.tolerance}, Capacity {result.capacity})")
        col1, col2 = st.columns(2)
        with col1:
            st.plotly_chart(risk_gauge(result.risk_score, result.risk_band), use_container_width=True)
        with col2:
            st.markdown(f"#### Recommended Model: {model.name}")
            st.plotly_chart(allocation_donut(model.allocation, model.name), use_container_width=True)
            st.caption(f"Expected return ≈ {model.expected_return*100:.1f}% · "
                       f"Est. volatility ≈ {model.est_volatility*100:.1f}%")
        st.caption("This standalone check does not overwrite an in-progress FinAdvisor journey. "
                   "Complete a journey in FinAdvisor to apply an updated risk profile to a goal plan.")

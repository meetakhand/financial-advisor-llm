"""Dashboard page: net worth, portfolio, risk, and financial-health overview.

Thin wrapper around ui/dashboard_components.py, which is also embedded in
the Report page and (compact form) directly inside the FinAdvisor chat panel.
"""
from __future__ import annotations

import streamlit as st

from ui.dashboard_components import render_full_dashboard
from ui.session import get_active_customer


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Dashboard")
    st.caption(f"{customer.name} · {customer.city}, {customer.country} · {customer.occupation}")

    pipeline_result = st.session_state.get("pipeline_result")
    render_full_dashboard(customer, pipeline_result=pipeline_result, compact=False, key_prefix="dash_")

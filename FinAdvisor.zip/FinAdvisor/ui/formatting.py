"""USD currency formatting helpers."""
from __future__ import annotations


def format_currency(amount: float, currency: str = "USD", decimals: int = 0) -> str:
    return f"${amount:,.{decimals}f}"


def compact_currency(amount: float, currency: str = "USD") -> str:
    """Compact form: $1.2M / $340K."""
    if abs(amount) >= 1_000_000:
        return f"${amount / 1_000_000:.2f}M"
    if abs(amount) >= 1_000:
        return f"${amount / 1_000:.1f}K"
    return f"${amount:,.0f}"


def format_pct(value: float, decimals: int = 1, signed: bool = False) -> str:
    if signed:
        return f"{value:+.{decimals}f}%"
    return f"{value:.{decimals}f}%"

"""Shared, embeddable dashboard building blocks.

Used by the standalone Dashboard page, the Report page (which embeds the
full dashboard), and the FinAdvisor chat panel (which embeds a compact
version right inside the conversation for the "AI-native" experience).
"""
from __future__ import annotations

import streamlit as st
import pandas as pd

from agents.portfolio_agent import analyze_portfolio
from core.data import get_decisions
from ui.formatting import compact_currency, format_pct
from ui.charts import (
    allocation_donut, risk_gauge, sector_bar, networth_bar, goal_progress_bar, current_vs_target_bars, drift_bar,
)

DECISION_BADGE = {"Approve": "✅ Approved", "Reject": "❌ Rejected", "Override": "✏️ Overridden"}


def render_key_metrics(customer, analysis):
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Savings", compact_currency(customer.total_savings, customer.currency))
    c2.metric("Portfolio Market Value", compact_currency(analysis.total_market_value, customer.currency))
    c3.metric("Gain / Loss", compact_currency(analysis.total_gain_loss, customer.currency),
              format_pct(analysis.total_gain_loss_pct, signed=True))
    c4.metric("Risk Band", customer.risk_band, f"Score {customer.risk_score}/100")


def render_networth_and_health(customer, analysis):
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Net Worth Breakdown")
        assets = {
            "Total Savings": customer.total_savings,
            "Portfolio": analysis.total_market_value,
            "Emergency Fund": customer.emergency_fund,
        }
        st.plotly_chart(networth_bar(assets), use_container_width=True, key=f"nw_{customer.id}_{id(analysis)}")
    with col2:
        st.markdown("#### Financial Health")
        months_covered = (customer.emergency_fund / customer.monthly_expenses) if customer.monthly_expenses else 0
        savings_rate = ((customer.annual_income / 12 - customer.monthly_expenses) / (customer.annual_income / 12) * 100) if customer.annual_income else 0
        st.metric("Emergency Fund Coverage", f"{months_covered:.1f} months")
        st.metric("Estimated Monthly Savings Rate", format_pct(savings_rate))
        st.metric("Dependents", customer.dependents)
        st.metric("Tax Bracket", customer.tax_bracket or "—")


def render_allocation_and_sectors(customer, analysis, key_prefix=""):
    if not analysis.has_holdings:
        st.info("No holdings on file for this customer. The Recommendation Engine uses the "
                "risk-based model portfolio as the starting target allocation.")
        return
    col1, col2 = st.columns(2)
    with col1:
        st.markdown("#### Current Portfolio Allocation")
        st.plotly_chart(allocation_donut(analysis.allocation_pct, "By Asset Class"),
                         use_container_width=True, key=f"{key_prefix}alloc_{customer.id}")
    with col2:
        st.markdown("#### Sector Breakdown")
        st.plotly_chart(sector_bar(analysis.sector_breakdown), use_container_width=True,
                         key=f"{key_prefix}sector_{customer.id}")


def render_holdings_table(analysis):
    if not analysis.has_holdings:
        return
    st.markdown("#### Holdings (with Start Date)")
    df = pd.DataFrame(analysis.by_holding)
    df = df[["symbol", "name", "asset_class", "sector", "units", "buy_price", "current_price",
             "market_value", "gain_loss", "gain_loss_pct", "start_date"]]
    df.columns = ["Symbol", "Name", "Asset Class", "Sector", "Units", "Buy Price", "Current Price",
                  "Market Value", "Gain/Loss", "Gain/Loss %", "Start Date"]
    st.dataframe(df, use_container_width=True, hide_index=True)


def render_risk_snapshot(customer, key_prefix=""):
    st.markdown("#### Risk Snapshot")
    st.plotly_chart(risk_gauge(customer.risk_score, customer.risk_band), use_container_width=True,
                     key=f"{key_prefix}riskgauge_{customer.id}")


def render_goal_progress(pipeline_result, customer, key_prefix=""):
    if pipeline_result is None:
        return
    gp = pipeline_result.goal_plan
    st.markdown(f"#### Goal Progress — {pipeline_result.journey}")
    st.plotly_chart(
        goal_progress_bar(gp.current_savings, gp.target_amount_future, label=pipeline_result.journey),
        use_container_width=True, key=f"{key_prefix}goalprog_{customer.id}",
    )
    c1, c2, c3 = st.columns(3)
    c1.metric("Target (future value)", compact_currency(gp.target_amount_future, customer.currency))
    c2.metric("Required Monthly SIP", compact_currency(gp.required_monthly_sip, customer.currency))
    c3.metric("Success Probability", f"{gp.success_prob}%")


def render_current_vs_target(pipeline_result, key_prefix=""):
    """Realistic current-vs-target allocation comparison, driven by whichever
    goal/journey is active and the currently-active recommendation (which may
    reflect a human Approve/Override decision)."""
    if pipeline_result is None or pipeline_result.rec_bundle is None:
        return
    rb = pipeline_result.rec_bundle
    st.markdown(f"#### Current vs Target Allocation — {pipeline_result.journey} ({rb.active_model})")
    if rb.is_overridden:
        st.caption(f"Target reflects a human-reviewed decision: {rb.override_note}")
    col1, col2 = st.columns(2)
    with col1:
        st.plotly_chart(current_vs_target_bars(rb.result.current_allocation, rb.result.target_allocation),
                         use_container_width=True, key=f"{key_prefix}cvt_{id(pipeline_result)}")
    with col2:
        st.plotly_chart(drift_bar(rb.result.drift), use_container_width=True,
                         key=f"{key_prefix}drift_{id(pipeline_result)}")
    c1, c2 = st.columns(2)
    c1.metric("Fit Score", f"{rb.result.fit_score:.0f}/100")
    c2.metric("Turnover Needed", f"{rb.result.turnover:.1f}%")


def render_decision_log(customer, journey: str = ""):
    if not customer.id:
        return
    decisions = get_decisions(customer.id, journey)
    if not decisions:
        return
    st.markdown("#### Human-in-the-Loop Decision Log")
    for d in decisions:
        badge = DECISION_BADGE.get(d["decision"], d["decision"])
        st.markdown(f"- {badge} — **{d['option_label']} ({d['model_name']})** _{d['created_at']}_  \n"
                    f"  > {d['comment']}")


def render_full_dashboard(customer, pipeline_result=None, compact: bool = False, key_prefix: str = ""):
    """Render the full dashboard. compact=True renders a lighter version
    (metrics + allocation + risk + goal progress + current-vs-target)
    suitable for embedding inline in the FinAdvisor chat panel.

    Uses the pipeline's own portfolio analysis (which reflects the
    Current Portfolio step / any holdings override) when a plan exists,
    so figures stay consistent between chat, Dashboard, and Report.
    """
    analysis = pipeline_result.portfolio_analysis if pipeline_result else analyze_portfolio(customer.holdings)

    render_key_metrics(customer, analysis)
    st.divider()

    if compact:
        render_allocation_and_sectors(customer, analysis, key_prefix=key_prefix)
        if pipeline_result:
            st.divider()
            render_goal_progress(pipeline_result, customer, key_prefix=key_prefix)
            st.divider()
            render_current_vs_target(pipeline_result, key_prefix=key_prefix)
            st.divider()
        render_risk_snapshot(customer, key_prefix=key_prefix)
        return

    render_networth_and_health(customer, analysis)
    st.divider()
    render_allocation_and_sectors(customer, analysis, key_prefix=key_prefix)
    render_holdings_table(analysis)
    st.divider()
    if pipeline_result:
        render_goal_progress(pipeline_result, customer, key_prefix=key_prefix)
        st.divider()
        render_current_vs_target(pipeline_result, key_prefix=key_prefix)
        st.divider()
    render_risk_snapshot(customer, key_prefix=key_prefix)
    if pipeline_result:
        st.divider()
        render_decision_log(customer, pipeline_result.journey)

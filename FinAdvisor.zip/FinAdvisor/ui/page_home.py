"""Home / Login page: pick one of the 100 seeded US customers, or start a
new customer intake. Loading or onboarding a customer takes you straight
into the FinAdvisor chat panel -- the primary AI-native experience."""
from __future__ import annotations

import streamlit as st

from core.data import all_customers, new_blank_customer
from ui.formatting import compact_currency


def _reset_session_for_new_customer():
    for key in ["chat_history", "active_journey", "journey_step", "goal_inputs",
                "risk_answers", "risk_result", "model", "pipeline_result",
                "override_model", "custom_allocation", "advisor_intro_shown",
                "hitl_decisions", "pending_hitl", "msg_counter", "ai_suggested_model",
                "awaiting_risk_quiz", "awaiting_portfolio_input", "portfolio_inputs"]:
        st.session_state.pop(key, None)


def render():
    st.title("NexWealth AI")
    st.caption("Multi-agent AI financial advisory — powered by FinAdvisor")

    st.markdown("### Select a customer")
    customers = all_customers()

    search = st.text_input("Search by name", "")
    filtered = [c for c in customers if search.lower() in c.name.lower()] if search else customers

    options = {f"#{c.id} — {c.name} ({c.city}, {c.occupation}, {compact_currency(c.annual_income, c.currency)}/yr)": c.id
               for c in filtered}

    if options:
        label = st.selectbox("Customer", list(options.keys()))
        if st.button("Load Customer", type="primary"):
            new_id = options[label]
            if st.session_state.get("customer_id") != new_id:
                _reset_session_for_new_customer()
            st.session_state.customer_id = new_id
            st.session_state.is_new_customer = False
            st.session_state.nav_redirect = "FinAdvisor"
            st.rerun()
    else:
        st.info("No customers match your search.")

    st.divider()
    st.markdown("### Or start a new customer")
    with st.form("new_customer_form"):
        name = st.text_input("Full name")
        age = st.number_input("Age", min_value=18, max_value=80, value=30)
        submitted = st.form_submit_button("Start New Customer Onboarding", type="primary")
        if submitted:
            _reset_session_for_new_customer()
            blank = new_blank_customer(name, int(age))
            st.session_state.new_customer = blank
            st.session_state.customer_id = 0
            st.session_state.is_new_customer = True
            st.session_state.nav_redirect = "FinAdvisor"
            st.rerun()

"""Report page: embedded live dashboard + composed summary + downloadable
markdown report (including the human-in-the-loop decision log)."""
from __future__ import annotations

import streamlit as st

from agents.report_agent import build_markdown_report
from ui.dashboard_components import render_full_dashboard
from ui.session import get_active_customer, require_plan


def render():
    customer = get_active_customer()
    if customer is None:
        st.info("No customer loaded yet. Go to **Home** to select or create a customer.")
        return

    st.title("Report")
    if not require_plan():
        return

    result = st.session_state.pipeline_result

    st.markdown("## 📊 Embedded Dashboard")
    with st.container(border=True):
        render_full_dashboard(customer, pipeline_result=result, compact=False, key_prefix="report_")

    st.divider()
    st.markdown("## 📝 Report Summary")
    report_md = build_markdown_report(
        customer, result.journey, result.goal_plan, result.risk_result, result.model,
        result.portfolio_analysis, result.benchmark_result, result.rec_bundle,
    )
    st.markdown(report_md)

    st.download_button(
        "Download Report (Markdown)", data=report_md,
        file_name=f"nexwealth_{customer.name.replace(' ', '_')}_{result.journey.replace(' ', '_')}.md",
        mime="text/markdown",
    )

    with st.expander("Agent pipeline that generated this report"):
        st.write(" → ".join(result.agents_run))

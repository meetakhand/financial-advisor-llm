"""Plotly chart helpers for NexWealth AI. Clean, professional theme:
sky-blue (#0EA5E9) / navy (#0B2440) accents."""
from __future__ import annotations

import plotly.graph_objects as go

SKY_BLUE = "#0EA5E9"
NAVY = "#0B2440"
GREEN = "#22C55E"
RED = "#EF4444"
AMBER = "#F59E0B"
GRAY = "#94A3B8"

ASSET_COLORS = {
    "Equity": SKY_BLUE,
    "International": "#38BDF8",
    "Fixed Income": NAVY,
    "Gold": AMBER,
    "Cash": GRAY,
}

BASE_LAYOUT = dict(
    font=dict(family="Inter, sans-serif", color="#0B2440"),
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=30, r=30, t=50, b=30),
    legend=dict(orientation="h", yanchor="bottom", y=-0.2),
)


def allocation_donut(allocation_pct: dict, title: str = "Allocation") -> go.Figure:
    labels = list(allocation_pct.keys())
    values = list(allocation_pct.values())
    colors = [ASSET_COLORS.get(l, GRAY) for l in labels]
    fig = go.Figure(data=[go.Pie(
        labels=labels, values=values, hole=0.55, marker=dict(colors=colors),
        textinfo="label+percent", sort=False,
    )])
    fig.update_layout(title=title, **BASE_LAYOUT)
    return fig


def risk_gauge(score: int, band: str) -> go.Figure:
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=score,
        title={"text": f"Risk Score — {band}"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": NAVY},
            "steps": [
                {"range": [0, 35], "color": "#DBEAFE"},
                {"range": [35, 55], "color": "#93C5FD"},
                {"range": [55, 75], "color": "#60A5FA"},
                {"range": [75, 100], "color": "#3B82F6"},
            ],
            "threshold": {"line": {"color": SKY_BLUE, "width": 4}, "value": score},
        },
    ))
    fig.update_layout(**BASE_LAYOUT)
    return fig


def fit_gauge(fit_score: float) -> go.Figure:
    color = GREEN if fit_score >= 80 else (AMBER if fit_score >= 60 else RED)
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=fit_score,
        title={"text": "Portfolio Fit Score"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": color},
        },
    ))
    fig.update_layout(**BASE_LAYOUT)
    return fig


def current_vs_target_bars(current_allocation: dict, target_allocation: dict) -> go.Figure:
    classes = list(target_allocation.keys())
    current_vals = [current_allocation.get(c, 0) for c in classes]
    target_vals = [target_allocation.get(c, 0) for c in classes]
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Current", x=classes, y=current_vals, marker_color=SKY_BLUE))
    fig.add_trace(go.Bar(name="Target", x=classes, y=target_vals, marker_color=NAVY))
    fig.update_layout(barmode="group", title="Current vs Target Allocation",
                       yaxis_title="%", **BASE_LAYOUT)
    return fig


def drift_bar(drift: dict) -> go.Figure:
    classes = list(drift.keys())
    values = list(drift.values())
    colors = [RED if v > 0 else GREEN for v in values]
    fig = go.Figure(go.Bar(x=classes, y=values, marker_color=colors))
    fig.add_hline(y=5, line_dash="dot", line_color=AMBER)
    fig.add_hline(y=-5, line_dash="dot", line_color=AMBER)
    fig.update_layout(title="Allocation Drift (Current − Target)", yaxis_title="Percentage points", **BASE_LAYOUT)
    return fig


def benchmark_line(portfolio_return: float, benchmark_return: float, broad_market_return: float,
                    labels: tuple[str, str, str] = ("Your Model", "Blended Benchmark", "Broad Market")) -> go.Figure:
    fig = go.Figure(go.Bar(
        x=list(labels), y=[portfolio_return * 100, benchmark_return * 100, broad_market_return * 100],
        marker_color=[SKY_BLUE, NAVY, GRAY],
        text=[f"{v*100:.1f}%" for v in (portfolio_return, benchmark_return, broad_market_return)],
        textposition="outside",
    ))
    fig.update_layout(title="12-Month Return Comparison", yaxis_title="Return (%)", **BASE_LAYOUT)
    return fig


def benchmark_growth_line(portfolio_return: float, benchmark_return: float, broad_market_return: float,
                           years: int = 10, start_value: float = 10000,
                           labels: tuple[str, str, str] = ("Your Model", "Blended Benchmark", "Broad Market")) -> go.Figure:
    """Illustrative growth-of-$10,000 line chart: each series compounds its
    12-month return flat across the horizon. Not a real historical backtest --
    a simple, readable way to visualize the return differential over time."""
    years = max(int(years), 1)
    x = list(range(years + 1))
    series = [
        (labels[0], portfolio_return, SKY_BLUE, "solid"),
        (labels[1], benchmark_return, NAVY, "dash"),
        (labels[2], broad_market_return, GRAY, "dot"),
    ]
    fig = go.Figure()
    for name, rate, color, dash in series:
        y = [start_value * ((1 + rate) ** t) for t in x]
        fig.add_trace(go.Scatter(
            x=x, y=y, mode="lines+markers", name=name,
            line=dict(color=color, width=3 if dash == "solid" else 2, dash=None if dash == "solid" else dash),
        ))
    fig.update_layout(
        title=f"Illustrative Growth of $10,000 over {years} Years",
        xaxis_title="Years", yaxis_title="Value ($)", **BASE_LAYOUT,
    )
    return fig


def goal_progress_bar(current: float, target: float, label: str = "Goal Progress") -> go.Figure:
    pct = min(current / target * 100, 100) if target else 0
    fig = go.Figure(go.Bar(
        x=[pct], y=[label], orientation="h", marker_color=SKY_BLUE,
        text=[f"{pct:.0f}% funded"], textposition="inside",
    ))
    fig.update_layout(xaxis=dict(range=[0, 100], title="% of target"), height=160, **BASE_LAYOUT)
    return fig


def networth_bar(assets: dict) -> go.Figure:
    labels = list(assets.keys())
    values = list(assets.values())
    fig = go.Figure(go.Bar(x=labels, y=values, marker_color=SKY_BLUE))
    fig.update_layout(title="Net Worth Breakdown", **BASE_LAYOUT)
    return fig


def sector_bar(sector_breakdown: dict) -> go.Figure:
    labels = list(sector_breakdown.keys())
    values = list(sector_breakdown.values())
    fig = go.Figure(go.Bar(x=values, y=labels, orientation="h", marker_color=NAVY))
    fig.update_layout(title="Sector Breakdown (%)", **BASE_LAYOUT)
    return fig

"""Client-layer safety guardrails: input screening + output screening.

Wraps every advisor/agent turn. Logs the intent + which agents ran (via
core.data.log_agent_run). Educational-only framing throughout.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

DISCLAIMER_US = (
    "\n\n---\n*Educational information personalized to your profile — not "
    "financial advice. NexWealth AI is not an SEC-registered investment "
    "adviser; consult a licensed professional before acting.*"
)

BLOCKED_PATTERNS = [
    r"\bignore (all|previous|prior) instructions\b",
    r"\bsystem prompt\b",
    r"\bact as (an? )?(unfiltered|jailbroken|dan)\b",
    r"\breveal (your|the) (api|secret|key)\b",
    r"\bsocial security number\b",
    r"\bcredit card number\b",
    r"\bpassword\b",
    r"\bhow (do|can) i (launder|evade tax(es)?) \b",
    r"\binsider trading\b",
    r"\bguarantee(d)? returns?\b",
]

OUT_OF_SCOPE_PATTERNS = [
    r"\bwrite (me )?(malware|a virus|ransomware)\b",
    r"\bhack (into|a)\b",
]

DEFLECT_MESSAGE = (
    "I can't help with that request — it's outside what FinAdvisor covers, "
    "or it looks like an attempt to change my instructions. I'm here to help "
    "with retirement planning, child education, buying a home, and general "
    "financial education. What would you like to explore?"
)

DEFINITIVE_DIRECTIVE_PATTERNS = [
    r"\byou (must|should definitely) buy\b",
    r"\bguaranteed to\b",
]


@dataclass
class GuardrailResult:
    allowed: bool
    text: str
    flagged: bool = False
    reason: str = ""


def screen_input(user_text: str) -> GuardrailResult:
    lowered = user_text.lower()
    for pattern in BLOCKED_PATTERNS + OUT_OF_SCOPE_PATTERNS:
        if re.search(pattern, lowered):
            return GuardrailResult(allowed=False, text=DEFLECT_MESSAGE, flagged=True,
                                    reason=f"input matched blocked pattern: {pattern}")
    # Strip obvious prompt-injection delimiters/attempts without blocking benign questions
    cleaned = re.sub(r"(?i)ignore (all|previous|prior) instructions", "[removed]", user_text)
    return GuardrailResult(allowed=True, text=cleaned)


def screen_output(response_text: str) -> str:
    text = response_text
    for pattern in DEFINITIVE_DIRECTIVE_PATTERNS:
        text = re.sub(pattern, "you may want to consider", text, flags=re.IGNORECASE)
    if "not financial advice" not in text.lower():
        text = text + DISCLAIMER_US
    return text


def apply_guardrails(user_text: str, generate_fn):
    """Wrap a single advisor/agent turn: screen input -> generate -> screen output.

    generate_fn receives the (possibly cleaned) input text and returns a response string.
    Returns (response_text, was_blocked: bool).
    """
    in_result = screen_input(user_text)
    if not in_result.allowed:
        return in_result.text, True
    raw_response = generate_fn(in_result.text)
    safe_response = screen_output(raw_response)
    return safe_response, False

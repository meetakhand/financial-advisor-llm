"""NexWealth AI — Streamlit entry point.

Multi-agent, RAG-augmented financial advisory demo. Locally hosted, works
fully offline with a rule-based fallback when no LLM key is configured.
Run: streamlit run app.py
"""
from __future__ import annotations

import streamlit as st

from core.data import init_db
import llm
from ui import page_home, page_advisor, page_dashboard, page_risk_profile
from ui import page_model_portfolios, page_benchmarking, page_recommendations, page_report
from ui.session import get_active_customer

st.set_page_config(page_title="NexWealth AI", page_icon="💠", layout="wide")

CUSTOM_CSS = """
<style>
:root { --nw-navy: #0B2440; --nw-sky: #0EA5E9; }
section[data-testid="stSidebar"] { background-color: var(--nw-navy); }
section[data-testid="stSidebar"] * { color: #E6F4FB !important; }
div.stButton > button[kind="primary"] { background-color: var(--nw-sky); border-color: var(--nw-sky); }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

init_db()

# Apply any pending redirect BEFORE the nav radio widget is instantiated --
# Streamlit forbids writing to a widget-bound session_state key after the
# widget has been created in the same script run.
_redirect = st.session_state.pop("nav_redirect", None)
if _redirect:
    st.session_state["nav_page"] = _redirect

PAGES = {
    "Home": page_home,
    "FinAdvisor": page_advisor,
    "Dashboard": page_dashboard,
    "Risk Profile": page_risk_profile,
    "Model Portfolios & Fit": page_model_portfolios,
    "Benchmarking": page_benchmarking,
    "Recommendations": page_recommendations,
    "Report": page_report,
}

AGENT_PIPELINE_LABEL = (
    "Intent Classification → Safety Guardrails → Agent Orchestrator → "
    "Goal Planning → Risk Profiling → Portfolio Analysis → Benchmarking → "
    "Recommendation → Report/Output"
)

with st.sidebar:
    st.markdown("## 💠 NexWealth AI")
    st.caption('"FinAdvisor" — the AI-Native Wealth Management Experience')
    st.caption("Plan, review, and approve investment decisions right in the chat panel.")

    customer = get_active_customer()
    if customer is not None:
        st.success(f"Active: **{customer.name}**\n\n{customer.country} · {customer.currency}"
                    + (" · New Customer" if not customer.id else f" · #{customer.id}"))
    else:
        st.info("No customer loaded")

    st.session_state.setdefault("nav_page", "Home")
    page_name = st.radio("Navigate", list(PAGES.keys()), label_visibility="collapsed", key="nav_page")

    st.divider()
    st.caption("**Agent pipeline**")
    st.caption(AGENT_PIPELINE_LABEL)
    st.divider()
    st.caption(f"LLM: {llm.provider_label()}")
    st.caption("Educational demo — not financial advice.")

PAGES[page_name].render()

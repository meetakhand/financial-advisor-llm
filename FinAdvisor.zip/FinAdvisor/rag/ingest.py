"""One-time (idempotent) ingestion of knowledge/*.md into a persistent
ChromaDB collection, embedded with sentence-transformers/all-MiniLM-L6-v2.

Run: python -m rag.ingest
"""
from __future__ import annotations

import os
import re
import glob

KNOWLEDGE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "knowledge")
CHROMA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".chroma")
COLLECTION_NAME = "nexwealth_knowledge"
EMBED_MODEL = "all-MiniLM-L6-v2"


def _chunk_text(text: str, title: str, max_chars: int = 800) -> list[dict]:
    """Split a markdown doc into paragraph-based chunks, each tagged with title."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    chunks = []
    buf = ""
    for p in paragraphs:
        if p.startswith("#") or p.startswith("Source:"):
            continue  # skip headings and the source attribution line
        if len(buf) + len(p) > max_chars and buf:
            chunks.append(buf.strip())
            buf = p
        else:
            buf = (buf + "\n\n" + p).strip()
    if buf:
        chunks.append(buf.strip())
    return [{"title": title, "text": c} for c in chunks]


def _load_documents() -> list[dict]:
    docs = []
    for path in sorted(glob.glob(os.path.join(KNOWLEDGE_DIR, "*.md"))):
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        first_line = content.strip().splitlines()[0] if content.strip() else os.path.basename(path)
        title = first_line.lstrip("#").strip() or os.path.basename(path)
        source_note = "Educational summary (see knowledge base source note in file header)"
        for chunk in _chunk_text(content, title):
            docs.append({
                "title": title,
                "source": os.path.basename(path),
                "text": chunk["text"],
            })
    return docs


def build_index(force: bool = False) -> int:
    """Build (or rebuild) the persistent Chroma collection. Returns chunk count.
    Returns 0 and does nothing if chromadb/sentence-transformers aren't available
    -- callers should fall back to keyword retrieval in that case.
    """
    try:
        import chromadb
        from chromadb.utils import embedding_functions
    except ImportError:
        return 0

    os.makedirs(CHROMA_DIR, exist_ok=True)
    client = chromadb.PersistentClient(path=CHROMA_DIR)

    if force:
        try:
            client.delete_collection(COLLECTION_NAME)
        except Exception:
            pass

    embed_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
    collection = client.get_or_create_collection(name=COLLECTION_NAME, embedding_function=embed_fn)

    if collection.count() > 0 and not force:
        return collection.count()

    docs = _load_documents()
    ids = [f"{d['source']}::{i}" for i, d in enumerate(docs)]
    documents = [d["text"] for d in docs]
    metadatas = [{"title": d["title"], "source": d["source"]} for d in docs]

    if documents:
        collection.add(ids=ids, documents=documents, metadatas=metadatas)
    return len(documents)


if __name__ == "__main__":
    n = build_index(force=True)
    print(f"Ingested {n} chunks from {KNOWLEDGE_DIR} into ChromaDB at {CHROMA_DIR}")

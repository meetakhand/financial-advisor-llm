"""Top-k retrieval over the ChromaDB knowledge collection, with a keyword
-matching fallback when chromadb/sentence-transformers aren't available or
the index hasn't been built (so Financial Q&A always returns something)."""
from __future__ import annotations

import os
import re
import glob
from dataclasses import dataclass

from rag.ingest import KNOWLEDGE_DIR, CHROMA_DIR, COLLECTION_NAME, EMBED_MODEL

TOP_K = 4


@dataclass
class RetrievedChunk:
    title: str
    source: str
    text: str
    score: float = 0.0


_keyword_docs_cache: list[dict] | None = None


def _load_keyword_docs() -> list[dict]:
    global _keyword_docs_cache
    if _keyword_docs_cache is not None:
        return _keyword_docs_cache
    docs = []
    for path in sorted(glob.glob(os.path.join(KNOWLEDGE_DIR, "*.md"))):
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        first_line = content.strip().splitlines()[0] if content.strip() else os.path.basename(path)
        title = first_line.lstrip("#").strip() or os.path.basename(path)
        paragraphs = [p.strip() for p in re.split(r"\n\s*\n", content)
                      if p.strip() and not p.startswith("#") and not p.startswith("Source:")]
        for p in paragraphs:
            docs.append({"title": title, "source": os.path.basename(path), "text": p})
    _keyword_docs_cache = docs
    return docs


def _keyword_retrieve(query: str, k: int = TOP_K) -> list[RetrievedChunk]:
    docs = _load_keyword_docs()
    q_words = set(re.findall(r"[a-z0-9]+", query.lower()))
    scored = []
    for d in docs:
        d_words = set(re.findall(r"[a-z0-9]+", d["text"].lower()))
        overlap = len(q_words & d_words)
        if overlap > 0:
            scored.append((overlap, d))
    scored.sort(key=lambda x: -x[0])
    if not scored:
        # No overlap at all -- return the most general doc (asset allocation) as a safe default
        fallback = [d for d in docs if "asset_allocation" in d["source"]][:1] or docs[:1]
        return [RetrievedChunk(title=d["title"], source=d["source"], text=d["text"], score=0.0) for d in fallback]
    return [RetrievedChunk(title=d["title"], source=d["source"], text=d["text"], score=float(s))
            for s, d in scored[:k]]


def _chroma_retrieve(query: str, k: int = TOP_K) -> list[RetrievedChunk] | None:
    try:
        import chromadb
        from chromadb.utils import embedding_functions
    except ImportError:
        return None
    try:
        client = chromadb.PersistentClient(path=CHROMA_DIR)
        embed_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBED_MODEL)
        collection = client.get_collection(name=COLLECTION_NAME, embedding_function=embed_fn)
        if collection.count() == 0:
            return None
        result = collection.query(query_texts=[query], n_results=k)
        chunks = []
        docs_list = result.get("documents", [[]])[0]
        metas_list = result.get("metadatas", [[]])[0]
        dists_list = result.get("distances", [[]])[0] if result.get("distances") else [0.0] * len(docs_list)
        for text, meta, dist in zip(docs_list, metas_list, dists_list):
            chunks.append(RetrievedChunk(
                title=meta.get("title", "Knowledge Base"),
                source=meta.get("source", ""),
                text=text,
                score=1.0 - dist,
            ))
        return chunks
    except Exception:
        return None


def retrieve(query: str, k: int = TOP_K) -> list[RetrievedChunk]:
    chroma_result = _chroma_retrieve(query, k)
    if chroma_result:
        return chroma_result
    return _keyword_retrieve(query, k)


def format_citations(chunks: list[RetrievedChunk]) -> str:
    seen = []
    for c in chunks:
        label = f"{c.title} ({c.source})"
        if label not in seen:
            seen.append(label)
    return "\n".join(f"- {s}" for s in seen)

"""FinAdvisor: the conversational AI Advisor agent.

Handles the Financial Q&A journey via RAG (ChromaDB retrieval + LLM
composition, with a deterministic templated fallback), and produces the
introduction message / journey routing used by the chat UI. Every reply is
personalized to the active customer and passed through guardrails.
"""
from __future__ import annotations

import llm
import guardrails
from rag.retriever import retrieve, format_citations

INTRO_MESSAGE = (
    "Hi, I'm **FinAdvisor** — your AI financial guide from NexWealth AI. "
    "I can help you with **Retirement Planning**, **Child Education**, "
    "**Buying a Home**, or any **Financial question**. Which would you like "
    "to explore?"
)


def intro_message(customer_name: str = "") -> str:
    if customer_name:
        return f"Hi {customer_name.split()[0]}! " + INTRO_MESSAGE[INTRO_MESSAGE.index("I'm"):]
    return INTRO_MESSAGE


def _template_answer(question: str, chunks, customer) -> str:
    if not chunks:
        return ("I don't have grounded information on that in my knowledge base yet. "
                "Could you rephrase, or ask about asset allocation, SIPs, emergency funds, "
                "retirement accounts, mutual funds/ETFs, diversification, bonds, inflation, or taxes?")
    lead = chunks[0]
    body = lead.text
    if len(body) > 650:
        body = body[:650].rsplit(".", 1)[0] + "."
    name = customer.name.split()[0] if customer and customer.name else "there"
    band = customer.risk_band if customer else "Moderate"
    personal_note = (f"\n\nGiven your **{band}** risk profile, this is worth weighing against your "
                      f"own goals and time horizon, {name}.")
    return f"{body}{personal_note}"


def _llm_answer(question: str, chunks, customer) -> str | None:
    if not llm.is_live():
        return None
    context = "\n\n".join(f"[{c.title}] {c.text}" for c in chunks)
    system = (
        "You are FinAdvisor, an educational financial guide for NexWealth AI. "
        "Answer ONLY using the provided context. Be concise (under 180 words), "
        "personalize the answer to the customer's profile, and end with one "
        "relevant follow-up question. Never give definitive buy/sell directives "
        "or guarantee returns. This is educational information, not financial advice."
    )
    profile = (f"Customer: {customer.name}, age {customer.age}, {customer.country}, "
               f"currency {customer.currency}, risk band {customer.risk_band}.") if customer else ""
    user_msg = f"{profile}\n\nContext:\n{context}\n\nQuestion: {question}"
    return llm.chat([{"role": "user", "content": user_msg}], system=system, max_tokens=350)


def answer_financial_question(question: str, customer) -> dict:
    """RAG pipeline: retrieve top-k -> compose grounded answer -> citations -> follow-up.
    Wrapped in guardrails (input + output screening)."""

    def _generate(clean_question: str) -> str:
        chunks = retrieve(clean_question)
        llm_text = _llm_answer(clean_question, chunks, customer)
        body = llm_text if llm_text else _template_answer(clean_question, chunks, customer)
        citations = format_citations(chunks)
        followup = _followup_for(clean_question)
        parts = [body]
        if citations:
            parts.append(f"\n**Sources:**\n{citations}")
        if followup and followup not in body:
            parts.append(f"\n_{followup}_")
        return "\n".join(parts)

    response, blocked = guardrails.apply_guardrails(question, _generate)
    return {"answer": response, "blocked": blocked}


def _followup_for(question: str) -> str:
    lowered = question.lower()
    if "emergency" in lowered:
        return "Would you like me to check how many months of expenses your current emergency fund covers?"
    if "sip" in lowered or "systematic" in lowered:
        return "Want me to calculate the required SIP for one of your goals?"
    if "tax" in lowered:
        return "Would you like a summary of tax-advantaged options available in your country?"
    if "etf" in lowered or "mutual fund" in lowered:
        return "Would you like to see how your current holdings are split between these?"
    return "Would you like to dive into Retirement Planning, Child Education, or Buying a Home next?"

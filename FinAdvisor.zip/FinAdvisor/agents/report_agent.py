"""Report/Output Agent.

Inputs: all upstream agent outputs.
Processing: compose a human-readable summary; run it through output safety
checks.
Output: dashboard-ready summary dict + a downloadable markdown report.
"""
from __future__ import annotations

from datetime import datetime

import guardrails
from core.data import get_decisions

DECISION_BADGE = {"Approve": "Approved", "Reject": "Rejected", "Override": "Overridden"}


def _fmt_money(amount: float, currency: str = "USD") -> str:
    return f"${amount:,.0f}"


def compose_summary(customer, journey: str, goal_plan, risk_result, model,
                     portfolio_analysis, benchmark_result, rec_bundle) -> dict:
    currency = customer.currency
    summary = {
        "customer_name": customer.name,
        "journey": journey,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "risk_score": risk_result.risk_score if risk_result else None,
        "risk_band": risk_result.risk_band if risk_result else None,
        "suggested_model": rec_bundle.ai_suggested_model if rec_bundle else None,
        "active_model": rec_bundle.active_model if rec_bundle else None,
        "is_overridden": rec_bundle.is_overridden if rec_bundle else False,
        "goal_target": _fmt_money(goal_plan.target_amount_future, currency) if goal_plan else None,
        "goal_years": goal_plan.years if goal_plan else None,
        "required_sip": _fmt_money(goal_plan.required_monthly_sip, currency) if goal_plan else None,
        "success_probability": goal_plan.success_prob if goal_plan else None,
        "fit_score": rec_bundle.result.fit_score if rec_bundle else None,
        "needs_rebalancing": rec_bundle.result.needs_rebalancing if rec_bundle else None,
        "benchmark_relative_return": benchmark_result.relative_return if benchmark_result else None,
    }
    return summary


def build_markdown_report(customer, journey: str, goal_plan, risk_result, model,
                           portfolio_analysis, benchmark_result, rec_bundle) -> str:
    currency = customer.currency
    lines = []
    lines.append(f"# NexWealth AI — {journey} Report")
    lines.append(f"**Customer:** {customer.name}  |  **Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")

    if risk_result:
        lines.append("## Risk Profile")
        lines.append(f"- Risk Score: **{risk_result.risk_score}/100**")
        lines.append(f"- Risk Band: **{risk_result.risk_band}**")
        lines.append(f"- Tolerance: {risk_result.tolerance} | Capacity: {risk_result.capacity}")
        lines.append("")

    if goal_plan:
        lines.append(f"## Goal: {goal_plan.journey}")
        lines.append(f"- Target amount (future value): {_fmt_money(goal_plan.target_amount_future, currency)}")
        lines.append(f"- Time horizon: {goal_plan.years:.0f} years")
        lines.append(f"- Current savings: {_fmt_money(goal_plan.current_savings, currency)}")
        lines.append(f"- Planned monthly contribution: {_fmt_money(goal_plan.planned_monthly_contribution, currency)}")
        lines.append(f"- Projected amount at horizon: {_fmt_money(goal_plan.projected_amount, currency)}")
        lines.append(f"- **Required monthly SIP: {_fmt_money(goal_plan.required_monthly_sip, currency)}**")
        lines.append(f"- Funding gap: {_fmt_money(goal_plan.funding_gap, currency)}")
        lines.append(f"- Success probability: **{goal_plan.success_prob}%**")
        lines.append("")

    if portfolio_analysis and portfolio_analysis.has_holdings:
        lines.append("## Current Portfolio")
        lines.append(f"- Total market value: {_fmt_money(portfolio_analysis.total_market_value, currency)}")
        lines.append(f"- Total gain/loss: {_fmt_money(portfolio_analysis.total_gain_loss, currency)} ({portfolio_analysis.total_gain_loss_pct:.1f}%)")
        lines.append("")

    if rec_bundle:
        lines.append("## Recommendation")
        lines.append(f"- AI-suggested model: **{rec_bundle.ai_suggested_model}**")
        lines.append(f"- Active model (after any human review): **{rec_bundle.active_model}**")
        if rec_bundle.is_overridden:
            lines.append(f"- ⚠️ Human override applied: {rec_bundle.override_note}")
        lines.append(f"- Fit score: {rec_bundle.result.fit_score}/100")
        lines.append(f"- Portfolio turnover needed: {rec_bundle.result.turnover:.1f}%")
        lines.append("")
        lines.append("### Target vs Current Allocation")
        lines.append("| Asset Class | Current % | Target % | Drift |")
        lines.append("|---|---|---|---|")
        for ac in rec_bundle.result.target_allocation:
            cur = rec_bundle.result.current_allocation.get(ac, 0)
            tgt = rec_bundle.result.target_allocation.get(ac, 0)
            drift = rec_bundle.result.drift.get(ac, 0)
            lines.append(f"| {ac} | {cur:.1f}% | {tgt:.1f}% | {drift:+.1f}% |")
        lines.append("")
        lines.append("### Prioritized Actions")
        for t in rec_bundle.text_recommendations:
            lines.append(f"- {t}")
        lines.append("")

    if benchmark_result:
        lines.append("## Benchmarking")
        lines.append(f"- Blended benchmark 12-mo return: {benchmark_result.blended_benchmark_return*100:.1f}%")
        lines.append(f"- Portfolio/model return: {benchmark_result.portfolio_return*100:.1f}%")
        lines.append(f"- Relative return: {benchmark_result.relative_return*100:+.1f}%")
        lines.append(f"- Tracking difference: {benchmark_result.tracking_difference*100:.1f}%")
        lines.append(f"- Broad market (S&P 500) return: {benchmark_result.broad_market_return*100:.1f}%")
        lines.append("")

    if customer.id:
        decisions = get_decisions(customer.id, journey)
        if decisions:
            lines.append("## Human-in-the-Loop Decision Log")
            lines.append("Every AI-generated investment option is reviewed by a human before it becomes active.")
            lines.append("")
            lines.append("| Option | Model | Decision | Response | When |")
            lines.append("|---|---|---|---|---|")
            for d in decisions:
                badge = DECISION_BADGE.get(d["decision"], d["decision"])
                comment = d["comment"].replace("|", "/").replace("\n", " ")
                lines.append(f"| {d['option_label']} | {d['model_name']} | {badge} | {comment} | {d['created_at']} |")
            lines.append("")

    report_text = "\n".join(lines)
    report_text = guardrails.screen_output(report_text)
    return report_text

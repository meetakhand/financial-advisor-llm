"""Goal Planning Agent.

Inputs: capability, target, timeline, contributions.
Processing: future value, required SIP, funding gap, success probability.
Output: goal plan dict.

Covers the three planning journeys: Retirement Planning, Child Education, Buy Home.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.calculators import future_value, required_sip, success_probability, inflate
from core.models import MODEL_PORTFOLIOS

US_INFLATION = 0.03  # illustrative long-run US CPI assumption
EDUCATION_INFLATION_PREMIUM = 0.02  # education costs have historically outpaced general inflation


@dataclass
class GoalPlan:
    journey: str
    target_amount_today: float
    target_amount_future: float
    years: float
    current_savings: float
    planned_monthly_contribution: float
    assumed_annual_return: float
    projected_amount: float
    required_monthly_sip: float
    funding_gap: float
    success_prob: float
    details: dict = field(default_factory=dict)


def _assumed_return(risk_band: str) -> float:
    return MODEL_PORTFOLIOS.get(risk_band, MODEL_PORTFOLIOS["Moderate"]).expected_return


def plan_retirement(current_age: int, target_retirement_age: int,
                     desired_monthly_income: float, current_savings: float,
                     monthly_contribution: float, risk_band: str,
                     withdrawal_years: int = 22) -> GoalPlan:
    years = max(target_retirement_age - current_age, 1)
    corpus_target_today = desired_monthly_income * 12 * withdrawal_years
    target_future = inflate(corpus_target_today, US_INFLATION, years)
    r = _assumed_return(risk_band)

    projected = future_value(current_savings, monthly_contribution, r, years)
    req_sip = required_sip(current_savings, target_future, r, years)
    gap = max(target_future - projected, 0)
    prob = success_probability(projected, target_future)

    return GoalPlan(
        journey="Retirement Planning", target_amount_today=corpus_target_today,
        target_amount_future=target_future, years=years, current_savings=current_savings,
        planned_monthly_contribution=monthly_contribution, assumed_annual_return=r,
        projected_amount=projected, required_monthly_sip=req_sip, funding_gap=gap,
        success_prob=prob,
        details={"target_retirement_age": target_retirement_age, "current_age": current_age,
                  "desired_monthly_income": desired_monthly_income, "withdrawal_years": withdrawal_years},
    )


def plan_child_education(child_current_age: int, target_cost_today: float,
                          current_savings: float, monthly_contribution: float,
                          risk_band: str, college_start_age: int = 18) -> GoalPlan:
    years = max(college_start_age - child_current_age, 1)
    target_future = inflate(target_cost_today, US_INFLATION + EDUCATION_INFLATION_PREMIUM, years)
    r = _assumed_return(risk_band)

    projected = future_value(current_savings, monthly_contribution, r, years)
    req_sip = required_sip(current_savings, target_future, r, years)
    gap = max(target_future - projected, 0)
    prob = success_probability(projected, target_future)

    return GoalPlan(
        journey="Child Education", target_amount_today=target_cost_today,
        target_amount_future=target_future, years=years, current_savings=current_savings,
        planned_monthly_contribution=monthly_contribution, assumed_annual_return=r,
        projected_amount=projected, required_monthly_sip=req_sip, funding_gap=gap,
        success_prob=prob,
        details={"child_current_age": child_current_age, "college_start_age": college_start_age},
    )


def plan_buy_home(home_price: float, down_payment_pct: float, target_purchase_year: int,
                   current_year: int, current_savings: float, monthly_saving_capacity: float,
                   risk_band: str) -> GoalPlan:
    years = max(target_purchase_year - current_year, 1)
    target_today = home_price * down_payment_pct / 100.0
    # Home purchases are near-term: use a more conservative assumed return regardless of risk band
    r = min(_assumed_return(risk_band), 0.07) if years > 3 else 0.045

    projected = future_value(current_savings, monthly_saving_capacity, r, years)
    req_sip = required_sip(current_savings, target_today, r, years)
    gap = max(target_today - projected, 0)
    prob = success_probability(projected, target_today)

    return GoalPlan(
        journey="Buy Home", target_amount_today=target_today, target_amount_future=target_today,
        years=years, current_savings=current_savings,
        planned_monthly_contribution=monthly_saving_capacity, assumed_annual_return=r,
        projected_amount=projected, required_monthly_sip=req_sip, funding_gap=gap,
        success_prob=prob,
        details={"home_price": home_price, "down_payment_pct": down_payment_pct,
                  "target_purchase_year": target_purchase_year},
    )

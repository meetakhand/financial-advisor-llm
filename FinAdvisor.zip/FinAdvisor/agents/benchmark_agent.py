"""Benchmarking Engine agent wrapper.

Inputs: current allocation, model portfolio, index returns.
Processing: map to closest benchmark; relative return, tracking, relative risk.
Output: benchmark comparison.
"""
from __future__ import annotations

from core.benchmark import compute_benchmark, BenchmarkResult
from core.models import ModelPortfolio
from agents.portfolio_agent import PortfolioAnalysis


def estimate_portfolio_return(analysis: PortfolioAnalysis) -> float | None:
    """Approximate realized annualized return from gain/loss % if holdings exist."""
    if not analysis.has_holdings or analysis.total_cost_basis <= 0:
        return None
    return analysis.total_gain_loss_pct / 100.0


def run_benchmarking(model: ModelPortfolio, analysis: PortfolioAnalysis | None = None) -> BenchmarkResult:
    realized = estimate_portfolio_return(analysis) if analysis else None
    return compute_benchmark(model, realized_portfolio_return=realized)

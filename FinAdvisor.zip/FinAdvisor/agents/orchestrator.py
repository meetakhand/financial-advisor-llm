"""Agent Orchestrator: central dispatcher.

Routes to specialized agents based on the selected capability and where the
user is in the flow (build spec section 4):

  Select capability -> Intent Classification + Safety Guardrails ->
  Agent Orchestrator -> Goal Setting -> Risk Profiling -> Portfolio Analysis
  (holdings provided? yes -> analyze : no -> use model target) ->
  Benchmarking -> Recommendation (drift >= 5% -> rebalancing plan) ->
  Report & Output.

Financial Q&A short-circuits straight to the RAG-backed advisor.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.data import Customer, log_agent_run
from agents import goal_agent, risk_agent, portfolio_agent, benchmark_agent, recommend_agent, report_agent

PLANNING_JOURNEYS = ["Retirement Planning", "Child Education", "Buy Home"]


@dataclass
class PipelineResult:
    journey: str
    goal_plan: object = None
    risk_result: object = None
    model: object = None
    portfolio_analysis: object = None
    benchmark_result: object = None
    rec_bundle: object = None
    summary: dict = field(default_factory=dict)
    report_markdown: str = ""
    agents_run: list = field(default_factory=list)


def run_goal_setting(journey: str, inputs: dict, risk_band: str):
    if journey == "Retirement Planning":
        return goal_agent.plan_retirement(
            current_age=inputs["current_age"], target_retirement_age=inputs["target_retirement_age"],
            desired_monthly_income=inputs["desired_monthly_income"], current_savings=inputs["current_savings"],
            monthly_contribution=inputs["monthly_contribution"], risk_band=risk_band,
        )
    if journey == "Child Education":
        return goal_agent.plan_child_education(
            child_current_age=inputs["child_current_age"], target_cost_today=inputs["target_cost_today"],
            current_savings=inputs["current_savings"], monthly_contribution=inputs["monthly_contribution"],
            risk_band=risk_band,
        )
    if journey == "Buy Home":
        return goal_agent.plan_buy_home(
            home_price=inputs["home_price"], down_payment_pct=inputs["down_payment_pct"],
            target_purchase_year=inputs["target_purchase_year"], current_year=inputs["current_year"],
            current_savings=inputs["current_savings"], monthly_saving_capacity=inputs["monthly_saving_capacity"],
            risk_band=risk_band,
        )
    raise ValueError(f"Unknown planning journey: {journey}")


def run_pipeline(customer: Customer, journey: str, goal_inputs: dict,
                  risk_answer_points: list[int] | None = None,
                  override_model_name: str | None = None,
                  custom_target_allocation: dict | None = None,
                  holdings_override: list | None = None) -> PipelineResult:
    """Run the full agent pipeline for a planning journey (Retirement /
    Child Education / Buy Home). Financial Q&A does not use this pipeline --
    see agents/advisor.py.

    holdings_override: when set (e.g. from the chat's Current Portfolio
    step), used instead of customer.holdings for Portfolio Analysis --
    lets a self-reported snapshot drive the plan without mutating the
    shared cached Customer object.
    """
    agents_run = ["Intent Classification", "Safety Guardrails"]

    # 1. Risk Profiling Agent
    if risk_answer_points is None:
        risk_answer_points = [1, 1, 1, 1, 1]  # neutral default if not yet answered
    risk_result, model = risk_agent.run_risk_profiling(
        risk_answer_points, customer.age, customer.annual_income, customer.dependents,
    )
    agents_run.append("Risk Profiling Agent")

    # 2. Goal Planning Agent
    goal_plan = run_goal_setting(journey, goal_inputs, risk_result.risk_band)
    agents_run.append("Goal Planning Agent")

    # 3. Portfolio Analysis Agent -- holdings provided? yes: analyze. no: empty/target-only.
    holdings = holdings_override if holdings_override is not None else customer.holdings
    analysis = portfolio_agent.analyze_portfolio(holdings)
    agents_run.append("Portfolio Analysis Agent")

    # 4. Benchmarking Engine
    benchmark_result = benchmark_agent.run_benchmarking(model, analysis)
    agents_run.append("Benchmarking Engine")

    # 5. Recommendation Engine (with optional human-in-the-loop override)
    current_allocation = analysis.allocation_pct if analysis.has_holdings else {ac: 0.0 for ac in model.allocation}
    if custom_target_allocation:
        rec_bundle = recommend_agent.apply_custom_allocation_override(
            current_allocation, risk_result.risk_band, custom_target_allocation,
        )
    elif override_model_name and override_model_name != risk_result.risk_band:
        rec_bundle = recommend_agent.apply_model_override(
            current_allocation, risk_result.risk_band, override_model_name,
        )
    else:
        rec_bundle = recommend_agent.run_recommendation(risk_result.risk_band, current_allocation)
    agents_run.append("Recommendation Engine")

    # 6. Report / Output Agent
    summary = report_agent.compose_summary(customer, journey, goal_plan, risk_result, model,
                                            analysis, benchmark_result, rec_bundle)
    report_md = report_agent.build_markdown_report(customer, journey, goal_plan, risk_result, model,
                                                     analysis, benchmark_result, rec_bundle)
    agents_run.append("Report/Output Agent")

    log_agent_run(customer.id, journey, agents_run)

    return PipelineResult(
        journey=journey, goal_plan=goal_plan, risk_result=risk_result, model=model,
        portfolio_analysis=analysis, benchmark_result=benchmark_result, rec_bundle=rec_bundle,
        summary=summary, report_markdown=report_md, agents_run=agents_run,
    )

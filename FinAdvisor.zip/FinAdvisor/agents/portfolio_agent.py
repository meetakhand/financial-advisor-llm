"""Portfolio Analysis Agent.

Inputs: holdings.
Processing: classify assets, market value, gain/loss, current allocation.
Output: current allocation (% by asset class) & P/L summary.

Decision point from the business flow: "Holdings provided? Yes -> analyze
current allocation. No -> use the risk model's target allocation as the
starting point" (handled by the caller/orchestrator).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as _date

from core.data import Holding
from core.models import ASSET_CLASSES

# Simplified categories used for the "Current Portfolio" chat step -- how a
# typical customer describes their holdings, mapped onto the asset classes
# the recommendation engine works with. Mutual Fund / Pensions are treated
# as blended (diversified-fund / target-date-style) accounts.
CATEGORY_ORDER = ["Equity", "Debt", "Mutual Fund", "Pensions"]
CATEGORY_ASSET_SPLIT = {
    "Equity": {"Equity": 1.0},
    "Debt": {"Fixed Income": 1.0},
    "Mutual Fund": {"Equity": 0.7, "Fixed Income": 0.3},
    "Pensions": {"Equity": 0.6, "Fixed Income": 0.4},
}
CATEGORY_DESCRIPTIONS = {
    "Equity": "Individual stocks or stock-focused brokerage holdings.",
    "Debt": "Bonds, bond funds, or other fixed-income holdings.",
    "Mutual Fund": "Diversified mutual funds (assumed ~70% equity / 30% fixed income).",
    "Pensions": "401(k), IRA, or other pension/retirement accounts (assumed ~60% equity / 40% fixed income).",
}


def build_holdings_from_categories(category_inputs: dict) -> list[Holding]:
    """category_inputs: {category: {"amount": float, "start_date": "YYYY-MM-DD"}}.
    Produces synthetic Holding rows (unit price $1) so the standard portfolio
    analysis / recommendation pipeline can operate on a self-reported,
    simplified current-portfolio snapshot."""
    holdings = []
    for category, split in CATEGORY_ASSET_SPLIT.items():
        entry = category_inputs.get(category)
        if not entry or entry.get("amount", 0) <= 0:
            continue
        amount = entry["amount"]
        start_date = entry.get("start_date", "")
        for asset_class, frac in split.items():
            if frac <= 0:
                continue
            holdings.append(Holding(
                symbol=category.replace(" ", "").upper(), name=category,
                units=round(amount * frac, 2), buy_price=1.0, current_price=1.0,
                sector=category, asset_class=asset_class, start_date=start_date,
            ))
    return holdings


def default_category_totals(customer) -> dict:
    """Pre-fill the Current Portfolio step from a seeded customer's existing
    holdings (Equity/International -> Equity, Fixed Income -> Debt); new
    customers with no holdings default to zero."""
    totals = {c: 0.0 for c in CATEGORY_ORDER}
    earliest = None
    for h in customer.holdings:
        if h.asset_class in ("Equity", "International"):
            totals["Equity"] += h.market_value
        elif h.asset_class == "Fixed Income":
            totals["Debt"] += h.market_value
        if h.start_date and (earliest is None or h.start_date < earliest):
            earliest = h.start_date
    default_date = earliest or _date.today().isoformat()
    return {c: {"amount": round(totals[c], -2), "start_date": default_date} for c in CATEGORY_ORDER}


@dataclass
class PortfolioAnalysis:
    total_market_value: float
    total_cost_basis: float
    total_gain_loss: float
    total_gain_loss_pct: float
    allocation_pct: dict          # asset class -> %
    allocation_value: dict        # asset class -> currency value
    by_holding: list              # list of dicts with per-holding detail
    sector_breakdown: dict        # sector -> %
    has_holdings: bool


def analyze_portfolio(holdings: list[Holding]) -> PortfolioAnalysis:
    if not holdings:
        return PortfolioAnalysis(
            total_market_value=0.0, total_cost_basis=0.0, total_gain_loss=0.0,
            total_gain_loss_pct=0.0, allocation_pct={ac: 0.0 for ac in ASSET_CLASSES},
            allocation_value={ac: 0.0 for ac in ASSET_CLASSES}, by_holding=[],
            sector_breakdown={}, has_holdings=False,
        )

    total_mv = sum(h.market_value for h in holdings)
    total_cb = sum(h.cost_basis for h in holdings)
    total_gl = total_mv - total_cb
    total_gl_pct = (total_gl / total_cb * 100) if total_cb else 0.0

    allocation_value = {ac: 0.0 for ac in ASSET_CLASSES}
    sector_value: dict[str, float] = {}
    by_holding = []
    for h in holdings:
        allocation_value[h.asset_class] = allocation_value.get(h.asset_class, 0.0) + h.market_value
        sector_value[h.sector] = sector_value.get(h.sector, 0.0) + h.market_value
        by_holding.append({
            "symbol": h.symbol, "name": h.name, "units": h.units,
            "buy_price": h.buy_price, "current_price": h.current_price,
            "market_value": h.market_value, "cost_basis": h.cost_basis,
            "gain_loss": h.gain_loss, "gain_loss_pct": h.gain_loss_pct,
            "asset_class": h.asset_class, "sector": h.sector,
            "start_date": h.start_date,
        })

    allocation_pct = {ac: (v / total_mv * 100 if total_mv else 0.0) for ac, v in allocation_value.items()}
    sector_breakdown = {s: (v / total_mv * 100 if total_mv else 0.0) for s, v in sector_value.items()}

    return PortfolioAnalysis(
        total_market_value=total_mv, total_cost_basis=total_cb, total_gain_loss=total_gl,
        total_gain_loss_pct=total_gl_pct, allocation_pct=allocation_pct,
        allocation_value=allocation_value, by_holding=by_holding,
        sector_breakdown=sector_breakdown, has_holdings=True,
    )

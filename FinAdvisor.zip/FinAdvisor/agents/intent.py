"""Intent Classification (client layer, runs every turn).

Captures which capability/journey the user means: Retirement Planning,
Child Education, Buy Home, or Financial Q&A. Uses the LLM when configured,
falls back to deterministic keyword matching otherwise -- always returns a
result, never raises.
"""
from __future__ import annotations

import re

import llm

CAPABILITIES = ["Retirement Planning", "Child Education", "Buy Home", "Financial Q&A"]

KEYWORDS = {
    "Retirement Planning": ["retire", "retirement", "pension", "401k", "401(k)", "nps", "corpus"],
    "Child Education": ["child", "kid", "education", "college", "tuition", "school fund"],
    "Buy Home": ["home", "house", "mortgage", "down payment", "down-payment", "property", "flat", "apartment"],
    "Financial Q&A": ["what is", "explain", "how much", "how do", "difference between", "should i", "tax", "sip", "etf", "emergency fund"],
}


def classify_keyword(text: str) -> str:
    lowered = text.lower()
    scores = {cap: 0 for cap in CAPABILITIES}
    for cap, words in KEYWORDS.items():
        for w in words:
            if w in lowered:
                scores[cap] += 1
    best = max(scores, key=scores.get)
    if scores[best] == 0:
        return "Financial Q&A"
    return best


def classify_intent(text: str, active_journey: str = "") -> str:
    """If the user is mid-journey, stay in that journey unless they clearly
    ask a general question. Otherwise classify from free text."""
    if active_journey and active_journey in CAPABILITIES[:3]:
        # still allow explicit switches
        lowered = text.lower()
        for cap in CAPABILITIES:
            if cap.lower().split()[0] in lowered and cap != active_journey:
                break
        else:
            return active_journey

    if llm.is_live():
        system = (
            "Classify the user's message into exactly one of these categories: "
            "Retirement Planning, Child Education, Buy Home, Financial Q&A. "
            "Reply with only the category name, nothing else."
        )
        result = llm.chat([{"role": "user", "content": text}], system=system, max_tokens=10)
        if result:
            cleaned = result.strip().strip(".")
            for cap in CAPABILITIES:
                if cap.lower() in cleaned.lower():
                    return cap
    return classify_keyword(text)

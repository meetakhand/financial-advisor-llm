"""Recommendation Engine agent.

Inputs: model, current allocation, goals, market.
Processing: target allocation %, drift, prioritized actions, fit score.
Output: recommendation set.

Human-in-the-loop: the recommended model/target allocation is a *suggestion*.
`apply_override` lets the user pick a different model band or hand-adjust the
target allocation; the drift/turnover/fit-score/actions are recomputed against
whatever allocation is currently active, and the override is recorded so the
Report agent can disclose that a human changed the AI's recommendation.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.models import ASSET_CLASSES, MODEL_PORTFOLIOS, ModelPortfolio, model_for_band
from core.recommend import (
    generate_recommendation, prioritized_text_recommendations, RecommendationResult,
)

MODEL_ORDER = ["Conservative", "Moderate", "Growth", "Aggressive"]

OPTION_RATIONALE = {
    "match": "Matches your assessed risk profile — the AI's primary suggestion.",
    "safer": "A more conservative alternative — less volatility, lower long-run growth potential.",
    "growth": "A more growth-oriented alternative — higher long-run growth potential, more volatility.",
}


@dataclass
class RecommendationBundle:
    ai_suggested_model: str
    active_model: str
    result: RecommendationResult
    text_recommendations: list
    is_overridden: bool
    override_note: str = ""
    custom_allocation: dict = field(default_factory=dict)


@dataclass
class InvestmentOption:
    label: str                # "Option 1", "Option 2", "Option 3"
    model: ModelPortfolio
    result: RecommendationResult
    rationale: str
    is_ai_suggested: bool


def run_recommendation(risk_band: str, current_allocation: dict) -> RecommendationBundle:
    model = model_for_band(risk_band)
    result = generate_recommendation(current_allocation, model)
    texts = prioritized_text_recommendations(result, model.name)
    return RecommendationBundle(
        ai_suggested_model=model.name, active_model=model.name, result=result,
        text_recommendations=texts, is_overridden=False,
    )


def apply_model_override(current_allocation: dict, ai_suggested_model: str,
                          override_model_name: str) -> RecommendationBundle:
    """User overrides the AI-suggested risk band/model with a different one."""
    model = MODEL_PORTFOLIOS.get(override_model_name, MODEL_PORTFOLIOS["Moderate"])
    result = generate_recommendation(current_allocation, model)
    texts = prioritized_text_recommendations(result, model.name)
    return RecommendationBundle(
        ai_suggested_model=ai_suggested_model, active_model=model.name, result=result,
        text_recommendations=texts, is_overridden=(override_model_name != ai_suggested_model),
        override_note=(f"Advisor overrode the AI-suggested {ai_suggested_model} model with {model.name}."
                        if override_model_name != ai_suggested_model else ""),
    )


def generate_investment_options(risk_band: str, current_allocation: dict) -> list[InvestmentOption]:
    """Produce exactly 3 distinct investment options centered on the AI-suggested
    model band, for human-in-the-loop review (Approve / Reject / Override)."""
    suggested = model_for_band(risk_band).name
    idx = MODEL_ORDER.index(suggested) if suggested in MODEL_ORDER else 1

    if idx == 0:
        chosen_idx = [0, 1, 2]
    elif idx == len(MODEL_ORDER) - 1:
        chosen_idx = [len(MODEL_ORDER) - 3, len(MODEL_ORDER) - 2, len(MODEL_ORDER) - 1]
    else:
        chosen_idx = [idx - 1, idx, idx + 1]

    options = []
    for n, i in enumerate(chosen_idx, start=1):
        name = MODEL_ORDER[i]
        model = MODEL_PORTFOLIOS[name]
        result = generate_recommendation(current_allocation, model)
        if name == suggested:
            rationale = OPTION_RATIONALE["match"]
        elif i < idx:
            rationale = OPTION_RATIONALE["safer"]
        else:
            rationale = OPTION_RATIONALE["growth"]
        options.append(InvestmentOption(
            label=f"Option {n}", model=model, result=result, rationale=rationale,
            is_ai_suggested=(name == suggested),
        ))
    return options


def apply_custom_allocation_override(current_allocation: dict, ai_suggested_model: str,
                                      custom_target: dict) -> RecommendationBundle:
    """User hand-edits the target allocation percentages directly."""
    total = sum(custom_target.get(ac, 0.0) for ac in ASSET_CLASSES)
    normalized = ({ac: round(custom_target.get(ac, 0.0) / total * 100, 1) for ac in ASSET_CLASSES}
                   if total > 0 else custom_target)
    synthetic_model = ModelPortfolio(name="Custom (User-Defined)", allocation=normalized,
                                      expected_return=0.0, est_volatility=0.0)
    result = generate_recommendation(current_allocation, synthetic_model)
    texts = prioritized_text_recommendations(result, synthetic_model.name)
    return RecommendationBundle(
        ai_suggested_model=ai_suggested_model, active_model=synthetic_model.name, result=result,
        text_recommendations=texts, is_overridden=True,
        override_note=f"Advisor replaced the AI-suggested {ai_suggested_model} allocation with a custom target.",
        custom_allocation=normalized,
    )

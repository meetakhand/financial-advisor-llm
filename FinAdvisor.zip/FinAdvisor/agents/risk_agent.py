"""Risk Profiling Agent.

Inputs: questionnaire answers, age, income, dependents.
Processing: tolerance + capacity -> Risk Score (0.6/0.4 blend) -> band.
Output: RiskResult (score + band) and the recommended model portfolio.
"""
from __future__ import annotations

from core.risk import compute_risk, QUESTIONNAIRE, RiskResult
from core.models import model_for_band, ModelPortfolio


def run_risk_profiling(answer_points: list[int], age: int, annual_income: float,
                        dependents: int) -> tuple[RiskResult, ModelPortfolio]:
    result = compute_risk(answer_points, age, annual_income, dependents)
    model = model_for_band(result.risk_band)
    return result, model


def questionnaire() -> list[dict]:
    return QUESTIONNAIRE
